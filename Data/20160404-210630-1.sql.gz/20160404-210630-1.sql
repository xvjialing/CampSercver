-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 3306
-- Database : onethink
-- 
-- Part : #1
-- Date : 2016-04-04 21:06:31
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `onethink_action`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_action`;
CREATE TABLE `onethink_action` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '行为唯一标识',
  `title` char(80) NOT NULL DEFAULT '' COMMENT '行为说明',
  `remark` char(140) NOT NULL DEFAULT '' COMMENT '行为描述',
  `rule` text NOT NULL COMMENT '行为规则',
  `log` text NOT NULL COMMENT '日志规则',
  `type` tinyint(2) unsigned NOT NULL DEFAULT '1' COMMENT '类型',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='系统行为表';

-- -----------------------------
-- Records of `onethink_action`
-- -----------------------------
INSERT INTO `onethink_action` VALUES ('1', 'user_login', '用户登录', '积分+10，每天一次', 'table:member|field:score|condition:uid={$self} AND status>-1|rule:score+10|cycle:24|max:1;', '[user|get_nickname]在[time|time_format]登录了后台', '1', '1', '1387181220');
INSERT INTO `onethink_action` VALUES ('2', 'add_article', '发布文章', '积分+5，每天上限5次', 'table:member|field:score|condition:uid={$self}|rule:score+5|cycle:24|max:5', '', '2', '0', '1380173180');
INSERT INTO `onethink_action` VALUES ('3', 'review', '评论', '评论积分+1，无限制', 'table:member|field:score|condition:uid={$self}|rule:score+1', '', '2', '1', '1383285646');
INSERT INTO `onethink_action` VALUES ('4', 'add_document', '发表文档', '积分+10，每天上限5次', 'table:member|field:score|condition:uid={$self}|rule:score+10|cycle:24|max:5', '[user|get_nickname]在[time|time_format]发表了一篇文章。\r\n表[model]，记录编号[record]。', '2', '0', '1386139726');
INSERT INTO `onethink_action` VALUES ('5', 'add_document_topic', '发表讨论', '积分+5，每天上限10次', 'table:member|field:score|condition:uid={$self}|rule:score+5|cycle:24|max:10', '', '2', '0', '1383285551');
INSERT INTO `onethink_action` VALUES ('6', 'update_config', '更新配置', '新增或修改或删除配置', '', '', '1', '1', '1383294988');
INSERT INTO `onethink_action` VALUES ('7', 'update_model', '更新模型', '新增或修改模型', '', '', '1', '1', '1383295057');
INSERT INTO `onethink_action` VALUES ('8', 'update_attribute', '更新属性', '新增或更新或删除属性', '', '', '1', '1', '1383295963');
INSERT INTO `onethink_action` VALUES ('9', 'update_channel', '更新导航', '新增或修改或删除导航', '', '', '1', '1', '1383296301');
INSERT INTO `onethink_action` VALUES ('10', 'update_menu', '更新菜单', '新增或修改或删除菜单', '', '', '1', '1', '1383296392');
INSERT INTO `onethink_action` VALUES ('11', 'update_category', '更新分类', '新增或修改或删除分类', '', '', '1', '1', '1383296765');

-- -----------------------------
-- Table structure for `onethink_action_log`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_action_log`;
CREATE TABLE `onethink_action_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `action_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '行为id',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '执行用户id',
  `action_ip` bigint(20) NOT NULL COMMENT '执行行为者ip',
  `model` varchar(50) NOT NULL DEFAULT '' COMMENT '触发行为的表',
  `record_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '触发行为的数据id',
  `remark` varchar(255) NOT NULL DEFAULT '' COMMENT '日志备注',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '执行行为的时间',
  PRIMARY KEY (`id`),
  KEY `action_ip_ix` (`action_ip`),
  KEY `action_id_ix` (`action_id`),
  KEY `user_id_ix` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=276 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='行为日志表';

-- -----------------------------
-- Records of `onethink_action_log`
-- -----------------------------
INSERT INTO `onethink_action_log` VALUES ('1', '1', '1', '2130706433', 'member', '1', 'admin在2015-11-19 19:13登录了后台', '1', '1447931593');
INSERT INTO `onethink_action_log` VALUES ('2', '1', '1', '2130706433', 'member', '1', 'admin在2015-11-22 12:46登录了后台', '1', '1448167591');
INSERT INTO `onethink_action_log` VALUES ('3', '1', '1', '2130706433', 'member', '1', 'admin在2015-12-09 20:13登录了后台', '1', '1449663202');
INSERT INTO `onethink_action_log` VALUES ('4', '10', '1', '2130706433', 'Menu', '122', '操作url：/onethink1/index.php?s=/admin/menu/add.html', '1', '1449664111');
INSERT INTO `onethink_action_log` VALUES ('5', '10', '1', '2130706433', 'Menu', '123', '操作url：/onethink1/index.php?s=/admin/menu/add.html', '1', '1449664162');
INSERT INTO `onethink_action_log` VALUES ('6', '10', '1', '2130706433', 'Menu', '124', '操作url：/onethink1/index.php?s=/admin/menu/add.html', '1', '1449664201');
INSERT INTO `onethink_action_log` VALUES ('7', '10', '1', '2130706433', 'Menu', '125', '操作url：/onethink1/index.php?s=/admin/menu/add.html', '1', '1449664538');
INSERT INTO `onethink_action_log` VALUES ('8', '10', '1', '2130706433', 'Menu', '126', '操作url：/onethink1/index.php?s=/admin/menu/add.html', '1', '1449664675');
INSERT INTO `onethink_action_log` VALUES ('9', '10', '1', '2130706433', 'Menu', '122', '操作url：/onethink1/index.php?s=/admin/menu/edit.html', '1', '1449664712');
INSERT INTO `onethink_action_log` VALUES ('10', '10', '1', '2130706433', 'Menu', '127', '操作url：/onethink1/index.php?s=/admin/menu/add.html', '1', '1449664856');
INSERT INTO `onethink_action_log` VALUES ('11', '10', '1', '2130706433', 'Menu', '128', '操作url：/onethink1/index.php?s=/admin/menu/add.html', '1', '1449664881');
INSERT INTO `onethink_action_log` VALUES ('12', '10', '1', '2130706433', 'Menu', '129', '操作url：/onethink1/index.php?s=/admin/menu/add.html', '1', '1449664965');
INSERT INTO `onethink_action_log` VALUES ('13', '10', '1', '2130706433', 'Menu', '130', '操作url：/onethink1/index.php?s=/admin/menu/add.html', '1', '1449664998');
INSERT INTO `onethink_action_log` VALUES ('14', '1', '3', '2130706433', 'member', '3', 'guest在2015-12-10 20:33登录了后台', '1', '1449750802');
INSERT INTO `onethink_action_log` VALUES ('15', '1', '3', '2130706433', 'member', '3', 'guest在2015-12-10 20:34登录了后台', '1', '1449750876');
INSERT INTO `onethink_action_log` VALUES ('16', '1', '3', '2130706433', 'member', '3', 'guest在2015-12-10 20:35登录了后台', '1', '1449750927');
INSERT INTO `onethink_action_log` VALUES ('17', '1', '3', '2130706433', 'member', '3', 'guest在2015-12-10 20:36登录了后台', '1', '1449750962');
INSERT INTO `onethink_action_log` VALUES ('18', '1', '3', '2130706433', 'member', '3', 'guest在2015-12-10 20:38登录了后台', '1', '1449751138');
INSERT INTO `onethink_action_log` VALUES ('19', '1', '3', '2130706433', 'member', '3', 'guest在2015-12-10 20:42登录了后台', '1', '1449751331');
INSERT INTO `onethink_action_log` VALUES ('20', '1', '3', '2130706433', 'member', '3', 'guest在2015-12-10 20:43登录了后台', '1', '1449751390');
INSERT INTO `onethink_action_log` VALUES ('21', '1', '3', '2130706433', 'member', '3', 'guest在2015-12-13 15:07登录了后台', '1', '1449990430');
INSERT INTO `onethink_action_log` VALUES ('22', '1', '1', '2130706433', 'member', '1', 'admin在2015-12-13 15:51登录了后台', '1', '1449993119');
INSERT INTO `onethink_action_log` VALUES ('23', '10', '1', '2130706433', 'Menu', '131', '操作url：/onethink/index.php?s=/Admin/Menu/add.html', '1', '1449994527');
INSERT INTO `onethink_action_log` VALUES ('24', '10', '1', '2130706433', 'Menu', '131', '操作url：/onethink/index.php?s=/Admin/Menu/edit.html', '1', '1449994576');
INSERT INTO `onethink_action_log` VALUES ('25', '10', '1', '2130706433', 'Menu', '132', '操作url：/onethink/index.php?s=/Admin/Menu/add.html', '1', '1449994633');
INSERT INTO `onethink_action_log` VALUES ('26', '10', '1', '2130706433', 'Menu', '133', '操作url：/onethink/index.php?s=/Admin/Menu/add.html', '1', '1449994668');
INSERT INTO `onethink_action_log` VALUES ('27', '10', '1', '2130706433', 'Menu', '131', '操作url：/onethink/index.php?s=/Admin/Menu/edit.html', '1', '1449995029');
INSERT INTO `onethink_action_log` VALUES ('28', '10', '1', '2130706433', 'Menu', '132', '操作url：/onethink/index.php?s=/Admin/Menu/edit.html', '1', '1449995075');
INSERT INTO `onethink_action_log` VALUES ('29', '10', '1', '2130706433', 'Menu', '133', '操作url：/onethink/index.php?s=/Admin/Menu/edit.html', '1', '1449995087');
INSERT INTO `onethink_action_log` VALUES ('30', '10', '1', '2130706433', 'Menu', '131', '操作url：/onethink/index.php?s=/Admin/Menu/edit.html', '1', '1449995164');
INSERT INTO `onethink_action_log` VALUES ('31', '10', '1', '2130706433', 'Menu', '131', '操作url：/onethink/index.php?s=/Admin/Menu/edit.html', '1', '1449995237');
INSERT INTO `onethink_action_log` VALUES ('32', '10', '1', '2130706433', 'Menu', '132', '操作url：/onethink/index.php?s=/Admin/Menu/edit.html', '1', '1449995254');
INSERT INTO `onethink_action_log` VALUES ('33', '10', '1', '2130706433', 'Menu', '133', '操作url：/onethink/index.php?s=/Admin/Menu/edit.html', '1', '1449995355');
INSERT INTO `onethink_action_log` VALUES ('34', '10', '1', '2130706433', 'Menu', '134', '操作url：/onethink/index.php?s=/Admin/Menu/add.html', '1', '1449995389');
INSERT INTO `onethink_action_log` VALUES ('35', '10', '1', '2130706433', 'Menu', '135', '操作url：/onethink/index.php?s=/Admin/Menu/add.html', '1', '1449995421');
INSERT INTO `onethink_action_log` VALUES ('36', '10', '1', '2130706433', 'Menu', '0', '操作url：/onethink/index.php?s=/Admin/Menu/del/id/134.html', '1', '1449995434');
INSERT INTO `onethink_action_log` VALUES ('37', '1', '1', '2130706433', 'member', '1', 'admin在2015-12-14 18:59登录了后台', '1', '1450090763');
INSERT INTO `onethink_action_log` VALUES ('38', '10', '1', '2130706433', 'Luser', '0', '操作url：/onethink1/index.php?s=/Admin/Ly/delu/userID/0.html', '1', '1450091001');
INSERT INTO `onethink_action_log` VALUES ('39', '1', '3', '2130706433', 'member', '3', 'guest在2015-12-14 19:12登录了后台', '1', '1450091578');
INSERT INTO `onethink_action_log` VALUES ('40', '1', '4', '2130706433', 'member', '4', 'guest1在2015-12-14 19:54登录了后台', '1', '1450094045');
INSERT INTO `onethink_action_log` VALUES ('41', '1', '4', '2130706433', 'member', '4', 'guest1在2015-12-14 20:18登录了后台', '1', '1450095503');
INSERT INTO `onethink_action_log` VALUES ('42', '1', '4', '2130706433', 'member', '4', 'guest1在2015-12-14 20:22登录了后台', '1', '1450095739');
INSERT INTO `onethink_action_log` VALUES ('43', '10', '1', '2130706433', 'Menu', '136', '操作url：/onethink1/index.php?s=/Admin/Menu/add.html', '1', '1450096940');
INSERT INTO `onethink_action_log` VALUES ('44', '10', '1', '2130706433', 'Menu', '133', '操作url：/onethink1/index.php?s=/Admin/Menu/edit.html', '1', '1450098628');
INSERT INTO `onethink_action_log` VALUES ('45', '10', '1', '2130706433', 'Menu', '137', '操作url：/onethink1/index.php?s=/Admin/Menu/add.html', '1', '1450098750');
INSERT INTO `onethink_action_log` VALUES ('46', '10', '1', '2130706433', 'Menu', '137', '操作url：/onethink1/index.php?s=/Admin/Menu/edit.html', '1', '1450098850');
INSERT INTO `onethink_action_log` VALUES ('47', '1', '1', '2130706433', 'member', '1', 'admin在2015-12-15 16:41登录了后台', '1', '1450168864');
INSERT INTO `onethink_action_log` VALUES ('48', '1', '4', '2130706433', 'member', '4', 'guest1在2015-12-15 19:28登录了后台', '1', '1450178930');
INSERT INTO `onethink_action_log` VALUES ('49', '1', '1', '2130706433', 'member', '1', 'admin在2015-12-20 12:54登录了后台', '1', '1450587262');
INSERT INTO `onethink_action_log` VALUES ('50', '1', '1', '2130706433', 'member', '1', 'admin在2015-12-22 15:53登录了后台', '1', '1450770781');
INSERT INTO `onethink_action_log` VALUES ('51', '10', '1', '2130706433', 'Menu', '138', '操作url：/onethink1/index.php?s=/Admin/Menu/add.html', '1', '1450772520');
INSERT INTO `onethink_action_log` VALUES ('52', '10', '1', '2130706433', 'Menu', '139', '操作url：/onethink1/index.php?s=/Admin/Menu/add.html', '1', '1450772787');
INSERT INTO `onethink_action_log` VALUES ('53', '10', '1', '2130706433', 'Menu', '139', '操作url：/onethink1/index.php?s=/Admin/Menu/edit.html', '1', '1450772987');
INSERT INTO `onethink_action_log` VALUES ('54', '10', '1', '2130706433', 'Menu', '140', '操作url：/onethink1/index.php?s=/Admin/Menu/add.html', '1', '1450773191');
INSERT INTO `onethink_action_log` VALUES ('55', '10', '1', '2130706433', 'Menu', '0', '操作url：/onethink1/index.php?s=/Admin/Menu/del/id/139.html', '1', '1450773351');
INSERT INTO `onethink_action_log` VALUES ('56', '10', '1', '2130706433', 'Menu', '0', '操作url：/onethink1/index.php?s=/Admin/Menu/del/id/140.html', '1', '1450773356');
INSERT INTO `onethink_action_log` VALUES ('57', '10', '1', '2130706433', 'Menu', '141', '操作url：/onethink1/index.php?s=/Admin/Menu/add.html', '1', '1450782731');
INSERT INTO `onethink_action_log` VALUES ('58', '10', '1', '2130706433', 'Menu', '141', '操作url：/onethink1/index.php?s=/Admin/Menu/edit.html', '1', '1450782780');
INSERT INTO `onethink_action_log` VALUES ('59', '10', '1', '2130706433', 'Menu', '142', '操作url：/onethink1/index.php?s=/Admin/Menu/add.html', '1', '1450782907');
INSERT INTO `onethink_action_log` VALUES ('60', '10', '1', '2130706433', 'Menu', '143', '操作url：/onethink1/index.php?s=/Admin/Menu/add.html', '1', '1450783540');
INSERT INTO `onethink_action_log` VALUES ('61', '10', '1', '2130706433', 'Menu', '144', '操作url：/onethink1/index.php?s=/Admin/Menu/add.html', '1', '1450783589');
INSERT INTO `onethink_action_log` VALUES ('62', '10', '1', '2130706433', 'Menu', '141', '操作url：/onethink1/index.php?s=/Admin/Menu/edit.html', '1', '1450783741');
INSERT INTO `onethink_action_log` VALUES ('63', '10', '1', '2130706433', 'Menu', '141', '操作url：/onethink1/index.php?s=/Admin/Menu/edit.html', '1', '1450783781');
INSERT INTO `onethink_action_log` VALUES ('64', '10', '1', '2130706433', 'Menu', '138', '操作url：/onethink1/index.php?s=/Admin/Menu/edit.html', '1', '1450784884');
INSERT INTO `onethink_action_log` VALUES ('65', '1', '1', '2130706433', 'member', '1', 'admin在2015-12-23 15:32登录了后台', '1', '1450855972');
INSERT INTO `onethink_action_log` VALUES ('66', '1', '1', '2130706433', 'member', '1', 'admin在2015-12-25 15:18登录了后台', '1', '1451027909');
INSERT INTO `onethink_action_log` VALUES ('67', '1', '1', '2130706433', 'member', '1', 'admin在2015-12-25 15:19登录了后台', '1', '1451027979');
INSERT INTO `onethink_action_log` VALUES ('68', '1', '1', '2130706433', 'member', '1', 'admin在2015-12-27 13:08登录了后台', '1', '1451192910');
INSERT INTO `onethink_action_log` VALUES ('69', '1', '1', '2130706433', 'member', '1', 'admin在2016-01-16 09:07登录了后台', '1', '1452906444');
INSERT INTO `onethink_action_log` VALUES ('70', '10', '1', '2130706433', 'Menu', '143', '操作url：/onethink1/index.php?s=/Admin/Menu/edit.html', '1', '1452930788');
INSERT INTO `onethink_action_log` VALUES ('71', '10', '1', '2130706433', 'Menu', '143', '操作url：/onethink1/index.php?s=/Admin/Menu/edit.html', '1', '1452930880');
INSERT INTO `onethink_action_log` VALUES ('72', '8', '1', '2130706433', 'attribute', '35', '操作url：/onethink1/index.php?s=/Admin/Attribute/update.html', '1', '1453027950');
INSERT INTO `onethink_action_log` VALUES ('73', '8', '1', '2130706433', 'attribute', '9', '操作url：/onethink1/index.php?s=/Admin/Attribute/update.html', '1', '1453028513');
INSERT INTO `onethink_action_log` VALUES ('74', '8', '1', '2130706433', 'attribute', '9', '操作url：/onethink1/index.php?s=/Admin/Attribute/update.html', '1', '1453028537');
INSERT INTO `onethink_action_log` VALUES ('75', '8', '1', '2130706433', 'attribute', '35', '操作url：/onethink1/index.php?s=/Admin/Attribute/update.html', '1', '1453028612');
INSERT INTO `onethink_action_log` VALUES ('76', '8', '1', '2130706433', 'attribute', '3', '操作url：/onethink1/index.php?s=/Admin/Attribute/update.html', '1', '1453028696');
INSERT INTO `onethink_action_log` VALUES ('77', '8', '1', '2130706433', 'attribute', '36', '操作url：/onethink1/index.php?s=/Admin/Attribute/update.html', '1', '1453028772');
INSERT INTO `onethink_action_log` VALUES ('78', '8', '1', '2130706433', 'attribute', '36', '操作url：/onethink1/index.php?s=/Admin/Attribute/remove/id/36.html', '1', '1453028811');
INSERT INTO `onethink_action_log` VALUES ('79', '8', '1', '2130706433', 'attribute', '2', '操作url：/onethink1/index.php?s=/Admin/Attribute/update.html', '1', '1453028854');
INSERT INTO `onethink_action_log` VALUES ('80', '8', '1', '2130706433', 'attribute', '5', '操作url：/onethink1/index.php?s=/Admin/Attribute/update.html', '1', '1453029121');
INSERT INTO `onethink_action_log` VALUES ('81', '8', '1', '2130706433', 'attribute', '37', '操作url：/onethink1/index.php?s=/Admin/Attribute/update.html', '1', '1453029150');
INSERT INTO `onethink_action_log` VALUES ('82', '8', '1', '2130706433', 'attribute', '38', '操作url：/onethink1/index.php?s=/Admin/Attribute/update.html', '1', '1453029310');
INSERT INTO `onethink_action_log` VALUES ('83', '8', '1', '2130706433', 'attribute', '12', '操作url：/onethink1/index.php?s=/Admin/Attribute/update.html', '1', '1453029366');
INSERT INTO `onethink_action_log` VALUES ('84', '1', '1', '2130706433', 'member', '1', 'admin在2016-01-18 09:41登录了后台', '1', '1453081278');
INSERT INTO `onethink_action_log` VALUES ('85', '8', '1', '2130706433', 'attribute', '23', '操作url：/onethink1/index.php?s=/Admin/Attribute/update.html', '1', '1453082797');
INSERT INTO `onethink_action_log` VALUES ('86', '8', '1', '2130706433', 'attribute', '25', '操作url：/onethink1/index.php?s=/Admin/Attribute/update.html', '1', '1453082810');
INSERT INTO `onethink_action_log` VALUES ('87', '8', '1', '2130706433', 'attribute', '26', '操作url：/onethink1/index.php?s=/Admin/Attribute/update.html', '1', '1453082824');
INSERT INTO `onethink_action_log` VALUES ('88', '7', '1', '2130706433', 'model', '2', '操作url：/onethink1/index.php?s=/Admin/Model/update.html', '1', '1453083936');
INSERT INTO `onethink_action_log` VALUES ('89', '7', '1', '2130706433', 'model', '2', '操作url：/onethink1/index.php?s=/Admin/Model/update.html', '1', '1453084009');
INSERT INTO `onethink_action_log` VALUES ('90', '8', '1', '2130706433', 'attribute', '19', '操作url：/onethink1/index.php?s=/Admin/Attribute/update.html', '1', '1453084499');
INSERT INTO `onethink_action_log` VALUES ('91', '8', '1', '2130706433', 'attribute', '13', '操作url：/onethink1/index.php?s=/Admin/Attribute/update.html', '1', '1453084777');
INSERT INTO `onethink_action_log` VALUES ('92', '8', '1', '2130706433', 'attribute', '11', '操作url：/onethink1/index.php?s=/Admin/Attribute/update.html', '1', '1453085074');
INSERT INTO `onethink_action_log` VALUES ('93', '8', '1', '2130706433', 'attribute', '10', '操作url：/onethink1/index.php?s=/Admin/Attribute/update.html', '1', '1453085096');
INSERT INTO `onethink_action_log` VALUES ('94', '8', '1', '2130706433', 'attribute', '39', '操作url：/onethink1/index.php?s=/Admin/Attribute/update.html', '1', '1453106387');
INSERT INTO `onethink_action_log` VALUES ('95', '7', '1', '2130706433', 'model', '2', '操作url：/onethink1/index.php?s=/Admin/Model/update.html', '1', '1453106475');
INSERT INTO `onethink_action_log` VALUES ('96', '1', '1', '2130706433', 'member', '1', 'admin在2016-01-19 09:57登录了后台', '1', '1453168668');
INSERT INTO `onethink_action_log` VALUES ('97', '8', '1', '2130706433', 'attribute', '38', '操作url：/onethink1/index.php?s=/Admin/Attribute/update.html', '1', '1453170015');
INSERT INTO `onethink_action_log` VALUES ('98', '8', '1', '2130706433', 'attribute', '16', '操作url：/onethink1/index.php?s=/Admin/Attribute/update.html', '1', '1453170384');
INSERT INTO `onethink_action_log` VALUES ('99', '8', '1', '2130706433', 'attribute', '17', '操作url：/onethink1/index.php?s=/Admin/Attribute/update.html', '1', '1453170421');
INSERT INTO `onethink_action_log` VALUES ('100', '7', '1', '2130706433', 'model', '2', '操作url：/onethink1/index.php?s=/Admin/Model/update.html', '1', '1453171546');
INSERT INTO `onethink_action_log` VALUES ('101', '7', '1', '2130706433', 'model', '2', '操作url：/onethink1/index.php?s=/Admin/Model/update.html', '1', '1453171617');
INSERT INTO `onethink_action_log` VALUES ('102', '7', '1', '2130706433', 'model', '4', '操作url：/onethink1/index.php?s=/Admin/Model/update.html', '1', '1453171712');
INSERT INTO `onethink_action_log` VALUES ('103', '8', '1', '2130706433', 'attribute', '33', '操作url：/onethink1/index.php?s=/Admin/Attribute/update.html', '1', '1453171791');
INSERT INTO `onethink_action_log` VALUES ('104', '8', '1', '2130706433', 'attribute', '34', '操作url：/onethink1/index.php?s=/Admin/Attribute/update.html', '1', '1453172156');
INSERT INTO `onethink_action_log` VALUES ('105', '8', '1', '2130706433', 'attribute', '35', '操作url：/onethink1/index.php?s=/Admin/Attribute/update.html', '1', '1453172289');
INSERT INTO `onethink_action_log` VALUES ('106', '8', '1', '2130706433', 'attribute', '36', '操作url：/onethink1/index.php?s=/Admin/Attribute/update.html', '1', '1453172349');
INSERT INTO `onethink_action_log` VALUES ('107', '8', '1', '2130706433', 'attribute', '37', '操作url：/onethink1/index.php?s=/Admin/Attribute/update.html', '1', '1453172381');
INSERT INTO `onethink_action_log` VALUES ('108', '8', '1', '2130706433', 'attribute', '38', '操作url：/onethink1/index.php?s=/Admin/Attribute/update.html', '1', '1453172764');
INSERT INTO `onethink_action_log` VALUES ('109', '8', '1', '2130706433', 'attribute', '39', '操作url：/onethink1/index.php?s=/Admin/Attribute/update.html', '1', '1453172902');
INSERT INTO `onethink_action_log` VALUES ('110', '7', '1', '2130706433', 'model', '4', '操作url：/onethink1/index.php?s=/Admin/Model/update.html', '1', '1453173045');
INSERT INTO `onethink_action_log` VALUES ('111', '7', '1', '2130706433', 'model', '4', '操作url：/onethink1/index.php?s=/Admin/Model/update.html', '1', '1453173059');
INSERT INTO `onethink_action_log` VALUES ('112', '8', '1', '2130706433', 'attribute', '40', '操作url：/onethink1/index.php?s=/Admin/Attribute/update.html', '1', '1453173217');
INSERT INTO `onethink_action_log` VALUES ('113', '8', '1', '2130706433', 'attribute', '41', '操作url：/onethink1/index.php?s=/Admin/Attribute/update.html', '1', '1453173300');
INSERT INTO `onethink_action_log` VALUES ('114', '8', '1', '2130706433', 'attribute', '42', '操作url：/onethink1/index.php?s=/Admin/Attribute/update.html', '1', '1453179455');
INSERT INTO `onethink_action_log` VALUES ('115', '7', '1', '2130706433', 'model', '4', '操作url：/onethink1/index.php?s=/Admin/Model/update.html', '1', '1453179503');
INSERT INTO `onethink_action_log` VALUES ('116', '7', '1', '2130706433', 'model', '4', '操作url：/onethink1/index.php?s=/Admin/Model/update.html', '1', '1453179686');
INSERT INTO `onethink_action_log` VALUES ('117', '7', '1', '2130706433', 'model', '4', '操作url：/onethink1/index.php?s=/Admin/Model/update.html', '1', '1453179813');
INSERT INTO `onethink_action_log` VALUES ('118', '7', '1', '2130706433', 'model', '4', '操作url：/onethink1/index.php?s=/Admin/Model/update.html', '1', '1453179865');
INSERT INTO `onethink_action_log` VALUES ('119', '7', '1', '2130706433', 'model', '4', '操作url：/onethink1/index.php?s=/Admin/Model/update.html', '1', '1453179878');
INSERT INTO `onethink_action_log` VALUES ('120', '7', '1', '2130706433', 'model', '4', '操作url：/onethink1/index.php?s=/Admin/Model/update.html', '1', '1453179901');
INSERT INTO `onethink_action_log` VALUES ('121', '11', '1', '2130706433', 'category', '39', '操作url：/onethink1/index.php?s=/Admin/Category/add.html', '1', '1453182788');
INSERT INTO `onethink_action_log` VALUES ('122', '7', '1', '2130706433', 'model', '4', '操作url：/onethink1/index.php?s=/Admin/Model/update.html', '1', '1453183008');
INSERT INTO `onethink_action_log` VALUES ('123', '8', '1', '2130706433', 'attribute', '43', '操作url：/onethink1/index.php?s=/Admin/Attribute/update.html', '1', '1453183260');
INSERT INTO `onethink_action_log` VALUES ('124', '7', '1', '2130706433', 'model', '4', '操作url：/onethink1/index.php?s=/Admin/Model/update.html', '1', '1453183287');
INSERT INTO `onethink_action_log` VALUES ('125', '7', '1', '2130706433', 'model', '4', '操作url：/onethink1/index.php?s=/Admin/Model/update.html', '1', '1453183510');
INSERT INTO `onethink_action_log` VALUES ('126', '8', '1', '2130706433', 'attribute', '20', '操作url：/onethink1/index.php?s=/Admin/Attribute/update.html', '1', '1453183612');
INSERT INTO `onethink_action_log` VALUES ('127', '8', '1', '2130706433', 'attribute', '20', '操作url：/onethink1/index.php?s=/Admin/Attribute/update.html', '1', '1453183625');
INSERT INTO `onethink_action_log` VALUES ('128', '8', '1', '2130706433', 'attribute', '17', '操作url：/onethink1/index.php?s=/Admin/Attribute/update.html', '1', '1453183652');
INSERT INTO `onethink_action_log` VALUES ('129', '7', '1', '2130706433', 'model', '4', '操作url：/onethink1/index.php?s=/Admin/Model/update.html', '1', '1453183677');
INSERT INTO `onethink_action_log` VALUES ('130', '7', '1', '2130706433', 'model', '4', '操作url：/onethink1/index.php?s=/Admin/Model/update.html', '1', '1453183854');
INSERT INTO `onethink_action_log` VALUES ('131', '8', '1', '2130706433', 'attribute', '35', '操作url：/onethink1/index.php?s=/Admin/Attribute/remove/id/35.html', '1', '1453184031');
INSERT INTO `onethink_action_log` VALUES ('132', '8', '1', '2130706433', 'attribute', '44', '操作url：/onethink1/index.php?s=/Admin/Attribute/update.html', '1', '1453184057');
INSERT INTO `onethink_action_log` VALUES ('133', '8', '1', '2130706433', 'attribute', '33', '操作url：/onethink1/index.php?s=/Admin/Attribute/remove/id/33.html', '1', '1453184148');
INSERT INTO `onethink_action_log` VALUES ('134', '8', '1', '2130706433', 'attribute', '45', '操作url：/onethink1/index.php?s=/Admin/Attribute/update.html', '1', '1453184170');
INSERT INTO `onethink_action_log` VALUES ('135', '8', '1', '2130706433', 'attribute', '40', '操作url：/onethink1/index.php?s=/Admin/Attribute/remove/id/40.html', '1', '1453184282');
INSERT INTO `onethink_action_log` VALUES ('136', '8', '1', '2130706433', 'attribute', '46', '操作url：/onethink1/index.php?s=/Admin/Attribute/update.html', '1', '1453184336');
INSERT INTO `onethink_action_log` VALUES ('137', '8', '1', '2130706433', 'attribute', '46', '操作url：/onethink1/index.php?s=/Admin/Attribute/update.html', '1', '1453184993');
INSERT INTO `onethink_action_log` VALUES ('138', '8', '1', '2130706433', 'attribute', '13', '操作url：/onethink1/index.php?s=/Admin/Attribute/update.html', '1', '1453185165');
INSERT INTO `onethink_action_log` VALUES ('139', '8', '1', '2130706433', 'attribute', '14', '操作url：/onethink1/index.php?s=/Admin/Attribute/update.html', '1', '1453185301');
INSERT INTO `onethink_action_log` VALUES ('140', '8', '1', '2130706433', 'attribute', '16', '操作url：/onethink1/index.php?s=/Admin/Attribute/update.html', '1', '1453185319');
INSERT INTO `onethink_action_log` VALUES ('141', '8', '1', '2130706433', 'attribute', '19', '操作url：/onethink1/index.php?s=/Admin/Attribute/update.html', '1', '1453185345');
INSERT INTO `onethink_action_log` VALUES ('142', '8', '1', '2130706433', 'attribute', '20', '操作url：/onethink1/index.php?s=/Admin/Attribute/update.html', '1', '1453185358');
INSERT INTO `onethink_action_log` VALUES ('143', '8', '1', '2130706433', 'attribute', '21', '操作url：/onethink1/index.php?s=/Admin/Attribute/update.html', '1', '1453185370');
INSERT INTO `onethink_action_log` VALUES ('144', '8', '1', '2130706433', 'attribute', '12', '操作url：/onethink1/index.php?s=/Admin/Attribute/update.html', '1', '1453185389');
INSERT INTO `onethink_action_log` VALUES ('145', '8', '1', '2130706433', 'attribute', '11', '操作url：/onethink1/index.php?s=/Admin/Attribute/update.html', '1', '1453185399');
INSERT INTO `onethink_action_log` VALUES ('146', '8', '1', '2130706433', 'attribute', '10', '操作url：/onethink1/index.php?s=/Admin/Attribute/update.html', '1', '1453185420');
INSERT INTO `onethink_action_log` VALUES ('147', '8', '1', '2130706433', 'attribute', '5', '操作url：/onethink1/index.php?s=/Admin/Attribute/remove/id/5.html', '1', '1453185509');
INSERT INTO `onethink_action_log` VALUES ('148', '7', '1', '2130706433', 'model', '4', '操作url：/onethink1/index.php?s=/Admin/Model/update.html', '1', '1453185719');
INSERT INTO `onethink_action_log` VALUES ('149', '11', '1', '2130706433', 'category', '2', '操作url：/onethink1/index.php?s=/Admin/Category/edit.html', '1', '1453185929');
INSERT INTO `onethink_action_log` VALUES ('150', '8', '1', '2130706433', 'attribute', '47', '操作url：/onethink1/index.php?s=/Admin/Attribute/update.html', '1', '1453186201');
INSERT INTO `onethink_action_log` VALUES ('151', '8', '1', '2130706433', 'attribute', '3', '操作url：/onethink1/index.php?s=/Admin/Attribute/update.html', '1', '1453187362');
INSERT INTO `onethink_action_log` VALUES ('152', '8', '1', '2130706433', 'attribute', '2', '操作url：/onethink1/index.php?s=/Admin/Attribute/update.html', '1', '1453187373');
INSERT INTO `onethink_action_log` VALUES ('153', '8', '1', '2130706433', 'attribute', '3', '操作url：/onethink1/index.php?s=/Admin/Attribute/update.html', '1', '1453187537');
INSERT INTO `onethink_action_log` VALUES ('154', '8', '1', '2130706433', 'attribute', '3', '操作url：/onethink1/index.php?s=/Admin/Attribute/update.html', '1', '1453187981');
INSERT INTO `onethink_action_log` VALUES ('155', '7', '1', '2130706433', 'model', '4', '操作url：/onethink1/index.php?s=/Admin/Model/update.html', '1', '1453188242');
INSERT INTO `onethink_action_log` VALUES ('156', '10', '1', '2130706433', 'Menu', '138', '操作url：/onethink1/index.php?s=/Admin/Menu/edit.html', '1', '1453188413');
INSERT INTO `onethink_action_log` VALUES ('157', '10', '1', '2130706433', 'Menu', '143', '操作url：/onethink1/index.php?s=/Admin/Menu/edit.html', '1', '1453188458');
INSERT INTO `onethink_action_log` VALUES ('158', '10', '1', '2130706433', 'Menu', '143', '操作url：/onethink1/index.php?s=/Admin/Menu/edit.html', '1', '1453189337');
INSERT INTO `onethink_action_log` VALUES ('159', '7', '1', '2130706433', 'model', '4', '操作url：/onethink1/index.php?s=/Admin/Model/update.html', '1', '1453190460');
INSERT INTO `onethink_action_log` VALUES ('160', '7', '1', '2130706433', 'model', '4', '操作url：/onethink1/index.php?s=/Admin/Model/update.html', '1', '1453190915');
INSERT INTO `onethink_action_log` VALUES ('161', '7', '1', '2130706433', 'model', '4', '操作url：/onethink1/index.php?s=/Admin/Model/update.html', '1', '1453191462');
INSERT INTO `onethink_action_log` VALUES ('162', '11', '1', '2130706433', 'category', '39', '操作url：/onethink1/index.php?s=/Admin/Category/edit.html', '1', '1453202785');
INSERT INTO `onethink_action_log` VALUES ('163', '11', '1', '2130706433', 'category', '40', '操作url：/onethink1/index.php?s=/Admin/Category/add.html', '1', '1453202849');
INSERT INTO `onethink_action_log` VALUES ('164', '1', '1', '2130706433', 'member', '1', 'admin在2016-02-19 14:10登录了后台', '1', '1455862212');
INSERT INTO `onethink_action_log` VALUES ('165', '1', '1', '2130706433', 'member', '1', 'admin在2016-02-24 13:46登录了后台', '1', '1456292797');
INSERT INTO `onethink_action_log` VALUES ('166', '1', '4', '2130706433', 'member', '4', 'guest1在2016-02-24 15:14登录了后台', '1', '1456298097');
INSERT INTO `onethink_action_log` VALUES ('167', '1', '1', '2130706433', 'member', '1', 'admin在2016-02-25 18:29登录了后台', '1', '1456396188');
INSERT INTO `onethink_action_log` VALUES ('168', '10', '1', '2130706433', 'Menu', '145', '操作url：/onethink1/index.php?s=/Admin/Menu/add.html', '1', '1456400069');
INSERT INTO `onethink_action_log` VALUES ('169', '10', '1', '2130706433', 'Menu', '141', '操作url：/onethink1/index.php?s=/Admin/Menu/edit.html', '1', '1456400215');
INSERT INTO `onethink_action_log` VALUES ('170', '10', '1', '2130706433', 'Menu', '146', '操作url：/onethink1/index.php?s=/Admin/Menu/add.html', '1', '1456400295');
INSERT INTO `onethink_action_log` VALUES ('171', '10', '1', '2130706433', 'Menu', '146', '操作url：/onethink1/index.php?s=/Admin/Menu/edit.html', '1', '1456403336');
INSERT INTO `onethink_action_log` VALUES ('172', '10', '1', '2130706433', 'Menu', '138', '操作url：/onethink1/index.php?s=/Admin/Menu/edit.html', '1', '1456404759');
INSERT INTO `onethink_action_log` VALUES ('173', '10', '1', '2130706433', 'Menu', '146', '操作url：/onethink1/index.php?s=/Admin/Menu/edit.html', '1', '1456404783');
INSERT INTO `onethink_action_log` VALUES ('174', '10', '1', '2130706433', 'Menu', '141', '操作url：/onethink1/index.php?s=/Admin/Menu/edit.html', '1', '1456404798');
INSERT INTO `onethink_action_log` VALUES ('175', '10', '1', '2130706433', 'Menu', '142', '操作url：/onethink1/index.php?s=/Admin/Menu/edit.html', '1', '1456404850');
INSERT INTO `onethink_action_log` VALUES ('176', '1', '1', '2130706433', 'member', '1', 'admin在2016-02-26 16:17登录了后台', '1', '1456474621');
INSERT INTO `onethink_action_log` VALUES ('177', '10', '1', '2130706433', 'Menu', '146', '操作url：/onethink1/index.php?s=/Admin/Menu/edit.html', '1', '1456485236');
INSERT INTO `onethink_action_log` VALUES ('178', '1', '1', '2130706433', 'member', '1', 'admin在2016-02-28 10:12登录了后台', '1', '1456625545');
INSERT INTO `onethink_action_log` VALUES ('179', '10', '1', '2130706433', 'Menu', '147', '操作url：/onethink1/index.php?s=/Admin/Menu/add.html', '1', '1456626282');
INSERT INTO `onethink_action_log` VALUES ('180', '10', '1', '2130706433', 'Menu', '148', '操作url：/onethink1/index.php?s=/Admin/Menu/add.html', '1', '1456626950');
INSERT INTO `onethink_action_log` VALUES ('181', '10', '1', '2130706433', 'Menu', '148', '操作url：/onethink1/index.php?s=/Admin/Menu/edit.html', '1', '1456626999');
INSERT INTO `onethink_action_log` VALUES ('182', '10', '1', '2130706433', 'Menu', '149', '操作url：/onethink1/index.php?s=/Admin/Menu/add.html', '1', '1456628115');
INSERT INTO `onethink_action_log` VALUES ('183', '10', '1', '2130706433', 'Menu', '149', '操作url：/onethink1/index.php?s=/Admin/Menu/edit.html', '1', '1456628197');
INSERT INTO `onethink_action_log` VALUES ('184', '10', '1', '2130706433', 'Menu', '148', '操作url：/onethink1/index.php?s=/Admin/Menu/edit.html', '1', '1456628259');
INSERT INTO `onethink_action_log` VALUES ('185', '10', '1', '2130706433', 'Menu', '150', '操作url：/onethink1/index.php?s=/Admin/Menu/add.html', '1', '1456636847');
INSERT INTO `onethink_action_log` VALUES ('186', '10', '1', '2130706433', 'Menu', '151', '操作url：/onethink1/index.php?s=/Admin/Menu/add.html', '1', '1456656743');
INSERT INTO `onethink_action_log` VALUES ('187', '10', '1', '2130706433', 'Menu', '151', '操作url：/onethink1/index.php?s=/Admin/Menu/edit.html', '1', '1456656792');
INSERT INTO `onethink_action_log` VALUES ('188', '10', '1', '2130706433', 'Menu', '0', '操作url：/onethink1/index.php?s=/Admin/Menu/del/id/132.html', '1', '1456658069');
INSERT INTO `onethink_action_log` VALUES ('189', '10', '1', '2130706433', 'Menu', '131', '操作url：/onethink1/index.php?s=/Admin/Menu/edit.html', '1', '1456658325');
INSERT INTO `onethink_action_log` VALUES ('190', '10', '1', '2130706433', 'Menu', '0', '操作url：/onethink1/index.php?s=/Admin/Menu/del/id/142.html', '1', '1456659916');
INSERT INTO `onethink_action_log` VALUES ('191', '10', '1', '2130706433', 'Menu', '152', '操作url：/onethink1/index.php?s=/Admin/Menu/add.html', '1', '1456660574');
INSERT INTO `onethink_action_log` VALUES ('192', '10', '1', '2130706433', 'Menu', '153', '操作url：/onethink1/index.php?s=/Admin/Menu/add.html', '1', '1456661594');
INSERT INTO `onethink_action_log` VALUES ('193', '10', '0', '2130706433', 'Lagent', '0', '操作url：/onethink1/index.php?s=/Admin/Ly/del/agentID/3.html', '1', '1456663675');
INSERT INTO `onethink_action_log` VALUES ('194', '10', '0', '2130706433', 'Lagent', '0', '操作url：/onethink1/index.php?s=/Admin/Ly/del/agentID/4.html', '1', '1456663680');
INSERT INTO `onethink_action_log` VALUES ('195', '10', '1', '2130706433', 'Menu', '154', '操作url：/onethink1/index.php?s=/Admin/Menu/add.html', '1', '1456664635');
INSERT INTO `onethink_action_log` VALUES ('196', '1', '1', '2130706433', 'member', '1', 'admin在2016-02-29 16:51登录了后台', '1', '1456735900');
INSERT INTO `onethink_action_log` VALUES ('197', '1', '1', '2130706433', 'member', '1', 'admin在2016-03-01 19:24登录了后台', '1', '1456831440');
INSERT INTO `onethink_action_log` VALUES ('198', '10', '1', '2130706433', 'Menu', '155', '操作url：/onethink1/index.php?s=/Admin/Menu/add.html', '1', '1456832096');
INSERT INTO `onethink_action_log` VALUES ('199', '1', '1', '2130706433', 'member', '1', 'admin在2016-03-02 15:38登录了后台', '1', '1456904302');
INSERT INTO `onethink_action_log` VALUES ('200', '1', '1', '2130706433', 'member', '1', 'admin在2016-03-03 18:55登录了后台', '1', '1457002538');
INSERT INTO `onethink_action_log` VALUES ('201', '1', '1', '2130706433', 'member', '1', 'admin在2016-03-04 18:26登录了后台', '1', '1457087184');
INSERT INTO `onethink_action_log` VALUES ('202', '1', '4', '2130706433', 'member', '4', 'guest1在2016-03-04 20:11登录了后台', '1', '1457093499');
INSERT INTO `onethink_action_log` VALUES ('203', '1', '4', '2130706433', 'member', '4', 'guest1在2016-03-04 20:12登录了后台', '1', '1457093533');
INSERT INTO `onethink_action_log` VALUES ('204', '1', '1', '2130706433', 'member', '1', 'admin在2016-03-04 20:12登录了后台', '1', '1457093562');
INSERT INTO `onethink_action_log` VALUES ('205', '1', '4', '2130706433', 'member', '4', 'guest1在2016-03-04 20:13登录了后台', '1', '1457093615');
INSERT INTO `onethink_action_log` VALUES ('206', '1', '5', '2130706433', 'member', '5', 'guest2在2016-03-04 20:15登录了后台', '1', '1457093714');
INSERT INTO `onethink_action_log` VALUES ('207', '1', '5', '2130706433', 'member', '5', 'guest2在2016-03-04 20:16登录了后台', '1', '1457093795');
INSERT INTO `onethink_action_log` VALUES ('208', '1', '6', '2130706433', 'member', '6', 'guest3在2016-03-04 20:17登录了后台', '1', '1457093821');
INSERT INTO `onethink_action_log` VALUES ('209', '1', '5', '2130706433', 'member', '5', 'guest2在2016-03-04 20:20登录了后台', '1', '1457094008');
INSERT INTO `onethink_action_log` VALUES ('210', '10', '1', '2130706433', 'Menu', '122', '操作url：/onethink1/index.php?s=/Admin/Menu/edit.html', '1', '1457094603');
INSERT INTO `onethink_action_log` VALUES ('211', '11', '1', '2130706433', 'category', '40', '操作url：/onethink1/index.php?s=/Admin/Category/remove/id/40.html', '1', '1457095012');
INSERT INTO `onethink_action_log` VALUES ('212', '11', '1', '2130706433', 'category', '39', '操作url：/onethink1/index.php?s=/Admin/Category/remove/id/39.html', '1', '1457095017');
INSERT INTO `onethink_action_log` VALUES ('213', '10', '1', '2130706433', 'Menu', '156', '操作url：/onethink1/index.php?s=/Admin/Menu/add.html', '1', '1457095106');
INSERT INTO `onethink_action_log` VALUES ('214', '10', '1', '2130706433', 'Menu', '156', '操作url：/onethink1/index.php?s=/Admin/Menu/edit.html', '1', '1457095160');
INSERT INTO `onethink_action_log` VALUES ('215', '10', '1', '2130706433', 'Menu', '156', '操作url：/onethink1/index.php?s=/Admin/Menu/edit.html', '1', '1457095199');
INSERT INTO `onethink_action_log` VALUES ('216', '10', '1', '2130706433', 'Menu', '0', '操作url：/onethink1/index.php?s=/Admin/Menu/del/id/156.html', '1', '1457095230');
INSERT INTO `onethink_action_log` VALUES ('217', '1', '1', '2130706433', 'member', '1', 'admin在2016-03-06 10:46登录了后台', '1', '1457232401');
INSERT INTO `onethink_action_log` VALUES ('218', '10', '1', '2130706433', 'Menu', '157', '操作url：/onethink1/index.php?s=/Admin/Menu/add.html', '1', '1457233800');
INSERT INTO `onethink_action_log` VALUES ('219', '10', '1', '2130706433', 'Menu', '157', '操作url：/onethink1/index.php?s=/Admin/Menu/edit.html', '1', '1457235069');
INSERT INTO `onethink_action_log` VALUES ('220', '10', '1', '2130706433', 'Menu', '157', '操作url：/onethink1/index.php?s=/Admin/Menu/edit.html', '1', '1457235087');
INSERT INTO `onethink_action_log` VALUES ('221', '1', '1', '2130706433', 'member', '1', 'admin在2016-03-08 10:20登录了后台', '1', '1457403634');
INSERT INTO `onethink_action_log` VALUES ('222', '1', '1', '2130706433', 'member', '1', 'admin在2016-03-08 18:28登录了后台', '1', '1457432908');
INSERT INTO `onethink_action_log` VALUES ('223', '1', '1', '2130706433', 'member', '1', 'admin在2016-03-09 13:40登录了后台', '1', '1457502047');
INSERT INTO `onethink_action_log` VALUES ('224', '7', '1', '2130706433', 'model', '5', '操作url：/onethink1/index.php?s=/Admin/Model/update.html', '1', '1457510521');
INSERT INTO `onethink_action_log` VALUES ('225', '1', '4', '2130706433', 'member', '4', 'guest1在2016-03-09 18:45登录了后台', '1', '1457520312');
INSERT INTO `onethink_action_log` VALUES ('226', '1', '1', '2130706433', 'member', '1', 'admin在2016-03-09 18:46登录了后台', '1', '1457520411');
INSERT INTO `onethink_action_log` VALUES ('227', '1', '1', '2130706433', 'member', '1', 'admin在2016-03-10 18:35登录了后台', '1', '1457606153');
INSERT INTO `onethink_action_log` VALUES ('228', '1', '7', '2130706433', 'member', '7', 'agent1在2016-03-10 18:54登录了后台', '1', '1457607263');
INSERT INTO `onethink_action_log` VALUES ('229', '1', '1', '2130706433', 'member', '1', 'admin在2016-03-10 18:55登录了后台', '1', '1457607318');
INSERT INTO `onethink_action_log` VALUES ('230', '1', '1', '2130706433', 'member', '1', 'admin在2016-03-11 17:19登录了后台', '1', '1457687975');
INSERT INTO `onethink_action_log` VALUES ('231', '1', '1', '2130706433', 'member', '1', 'admin在2016-03-11 19:05登录了后台', '1', '1457694358');
INSERT INTO `onethink_action_log` VALUES ('232', '10', '1', '2130706433', 'Menu', '133', '操作url：/onethink1/index.php?s=/Admin/Menu/edit.html', '1', '1457694591');
INSERT INTO `onethink_action_log` VALUES ('233', '10', '1', '2130706433', 'Menu', '137', '操作url：/onethink1/index.php?s=/Admin/Menu/edit.html', '1', '1457694603');
INSERT INTO `onethink_action_log` VALUES ('234', '10', '1', '2130706433', 'Menu', '158', '操作url：/onethink1/index.php?s=/Admin/Menu/add.html', '1', '1457694656');
INSERT INTO `onethink_action_log` VALUES ('235', '10', '1', '2130706433', 'Menu', '159', '操作url：/onethink1/index.php?s=/Admin/Menu/add.html', '1', '1457694824');
INSERT INTO `onethink_action_log` VALUES ('236', '10', '1', '2130706433', 'Menu', '159', '操作url：/onethink1/index.php?s=/Admin/Menu/edit.html', '1', '1457694897');
INSERT INTO `onethink_action_log` VALUES ('237', '10', '1', '2130706433', 'Menu', '160', '操作url：/onethink1/index.php?s=/Admin/Menu/add.html', '1', '1457694932');
INSERT INTO `onethink_action_log` VALUES ('238', '10', '1', '2130706433', 'Menu', '159', '操作url：/onethink1/index.php?s=/Admin/Menu/edit.html', '1', '1457694981');
INSERT INTO `onethink_action_log` VALUES ('239', '10', '1', '2130706433', 'Menu', '131', '操作url：/onethink1/index.php?s=/Admin/Menu/edit.html', '1', '1457695256');
INSERT INTO `onethink_action_log` VALUES ('240', '10', '1', '2130706433', 'Menu', '0', '操作url：/onethink1/index.php?s=/Admin/Menu/del/id/158.html', '1', '1457695314');
INSERT INTO `onethink_action_log` VALUES ('241', '1', '9', '2130706433', 'member', '9', 'agent2在2016-03-11 19:32登录了后台', '1', '1457695932');
INSERT INTO `onethink_action_log` VALUES ('242', '10', '1', '2130706433', 'Menu', '159', '操作url：/onethink1/index.php?s=/Admin/Menu/edit.html', '1', '1457696116');
INSERT INTO `onethink_action_log` VALUES ('243', '10', '1', '2130706433', 'Menu', '160', '操作url：/onethink1/index.php?s=/Admin/Menu/edit.html', '1', '1457696138');
INSERT INTO `onethink_action_log` VALUES ('244', '10', '1', '2130706433', 'Menu', '2', '操作url：/onethink1/index.php?s=/Admin/Menu/edit.html', '1', '1457696221');
INSERT INTO `onethink_action_log` VALUES ('245', '10', '1', '2130706433', 'Menu', '2', '操作url：/onethink1/index.php?s=/Admin/Menu/edit.html', '1', '1457696394');
INSERT INTO `onethink_action_log` VALUES ('246', '10', '1', '2130706433', 'Menu', '16', '操作url：/onethink1/index.php?s=/Admin/Menu/edit.html', '1', '1457696432');
INSERT INTO `onethink_action_log` VALUES ('247', '10', '1', '2130706433', 'Menu', '0', '操作url：/onethink1/index.php?s=/Admin/Menu/del.html', '1', '1457696455');
INSERT INTO `onethink_action_log` VALUES ('248', '10', '1', '2130706433', 'Menu', '161', '操作url：/onethink1/index.php?s=/Admin/Menu/add.html', '1', '1457696491');
INSERT INTO `onethink_action_log` VALUES ('249', '10', '1', '2130706433', 'Menu', '162', '操作url：/onethink1/index.php?s=/Admin/Menu/add.html', '1', '1457696518');
INSERT INTO `onethink_action_log` VALUES ('250', '10', '1', '2130706433', 'Menu', '163', '操作url：/onethink1/index.php?s=/Admin/Menu/add.html', '1', '1457696745');
INSERT INTO `onethink_action_log` VALUES ('251', '10', '1', '2130706433', 'Menu', '0', '操作url：/onethink1/index.php?s=/Admin/Menu/del/id/131.html', '1', '1457696899');
INSERT INTO `onethink_action_log` VALUES ('252', '10', '1', '2130706433', 'Menu', '164', '操作url：/onethink1/index.php?s=/Admin/Menu/add.html', '1', '1457700522');
INSERT INTO `onethink_action_log` VALUES ('253', '1', '1', '2130706433', 'member', '1', 'admin在2016-03-12 12:47登录了后台', '1', '1457758066');
INSERT INTO `onethink_action_log` VALUES ('254', '10', '1', '2130706433', 'Menu', '165', '操作url：/onethink1/index.php?s=/Admin/Menu/add.html', '1', '1457769289');
INSERT INTO `onethink_action_log` VALUES ('255', '1', '1', '2130706433', 'member', '1', 'admin在2016-03-16 16:43登录了后台', '1', '1458117807');
INSERT INTO `onethink_action_log` VALUES ('256', '1', '1', '2130706433', 'member', '1', 'admin在2016-03-16 16:51登录了后台', '1', '1458118282');
INSERT INTO `onethink_action_log` VALUES ('257', '1', '1', '2130706433', 'member', '1', 'admin在2016-03-20 15:53登录了后台', '1', '1458460426');
INSERT INTO `onethink_action_log` VALUES ('258', '1', '1', '2130706433', 'member', '1', 'admin在2016-03-21 19:01登录了后台', '1', '1458558104');
INSERT INTO `onethink_action_log` VALUES ('259', '1', '1', '2130706433', 'member', '1', 'admin在2016-03-22 18:51登录了后台', '1', '1458643860');
INSERT INTO `onethink_action_log` VALUES ('260', '1', '1', '2130706433', 'member', '1', 'admin在2016-03-23 15:18登录了后台', '1', '1458717526');
INSERT INTO `onethink_action_log` VALUES ('261', '1', '1', '2130706433', 'member', '1', 'admin在2016-03-24 20:43登录了后台', '1', '1458823386');
INSERT INTO `onethink_action_log` VALUES ('262', '1', '1', '2130706433', 'member', '1', 'admin在2016-03-26 12:08登录了后台', '1', '1458965288');
INSERT INTO `onethink_action_log` VALUES ('263', '10', '1', '2130706433', 'Menu', '0', '操作url：/onethink1/index.php?s=/Admin/Menu/del/id/145.html', '1', '1458969293');
INSERT INTO `onethink_action_log` VALUES ('264', '10', '1', '2130706433', 'Menu', '0', '操作url：/onethink1/index.php?s=/Admin/Menu/del/id/165.html', '1', '1459060425');
INSERT INTO `onethink_action_log` VALUES ('265', '10', '1', '2130706433', 'Menu', '166', '操作url：/onethink1/index.php?s=/Admin/Menu/add.html', '1', '1459060530');
INSERT INTO `onethink_action_log` VALUES ('266', '10', '1', '2130706433', 'Menu', '167', '操作url：/onethink1/index.php?s=/Admin/Menu/add.html', '1', '1459060592');
INSERT INTO `onethink_action_log` VALUES ('267', '10', '1', '2130706433', 'Menu', '0', '操作url：/onethink1/index.php?s=/Admin/Menu/del/id/167.html', '1', '1459060868');
INSERT INTO `onethink_action_log` VALUES ('268', '10', '1', '2130706433', 'Menu', '0', '操作url：/onethink1/index.php?s=/Admin/Menu/del/id/164.html', '1', '1459060872');
INSERT INTO `onethink_action_log` VALUES ('269', '10', '1', '2130706433', 'Menu', '0', '操作url：/onethink1/index.php?s=/Admin/Menu/del/id/166.html', '1', '1459060929');
INSERT INTO `onethink_action_log` VALUES ('270', '10', '1', '2130706433', 'Menu', '168', '操作url：/onethink1/index.php?s=/Admin/Menu/add.html', '1', '1459061187');
INSERT INTO `onethink_action_log` VALUES ('271', '10', '1', '2130706433', 'Menu', '0', '操作url：/onethink1/index.php?s=/Admin/Menu/del/id/168.html', '1', '1459061251');
INSERT INTO `onethink_action_log` VALUES ('272', '10', '1', '2130706433', 'Menu', '169', '操作url：/onethink1/index.php?s=/Admin/Menu/add.html', '1', '1459062302');
INSERT INTO `onethink_action_log` VALUES ('273', '10', '1', '2130706433', 'Menu', '169', '操作url：/onethink1/index.php?s=/Admin/Menu/edit.html', '1', '1459062413');
INSERT INTO `onethink_action_log` VALUES ('274', '10', '1', '2130706433', 'Menu', '170', '操作url：/onethink1/index.php?s=/Admin/Menu/add.html', '1', '1459062471');
INSERT INTO `onethink_action_log` VALUES ('275', '1', '1', '2130706433', 'member', '1', 'admin在2016-04-04 21:02登录了后台', '1', '1459774930');

-- -----------------------------
-- Table structure for `onethink_addons`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_addons`;
CREATE TABLE `onethink_addons` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(40) NOT NULL COMMENT '插件名或标识',
  `title` varchar(20) NOT NULL DEFAULT '' COMMENT '中文名',
  `description` text COMMENT '插件描述',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `config` text COMMENT '配置',
  `author` varchar(40) DEFAULT '' COMMENT '作者',
  `version` varchar(20) DEFAULT '' COMMENT '版本号',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '安装时间',
  `has_adminlist` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否有后台列表',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COMMENT='插件表';

-- -----------------------------
-- Records of `onethink_addons`
-- -----------------------------
INSERT INTO `onethink_addons` VALUES ('15', 'EditorForAdmin', '后台编辑器', '用于增强整站长文本的输入和显示', '1', '{\"editor_type\":\"2\",\"editor_wysiwyg\":\"1\",\"editor_height\":\"500px\",\"editor_resize_type\":\"1\"}', 'thinkphp', '0.1', '1383126253', '0');
INSERT INTO `onethink_addons` VALUES ('2', 'SiteStat', '站点统计信息', '统计站点的基础信息', '1', '{\"title\":\"\\u7cfb\\u7edf\\u4fe1\\u606f\",\"width\":\"1\",\"display\":\"1\",\"status\":\"0\"}', 'thinkphp', '0.1', '1379512015', '0');
INSERT INTO `onethink_addons` VALUES ('3', 'DevTeam', '开发团队信息', '开发团队成员信息', '1', '{\"title\":\"OneThink\\u5f00\\u53d1\\u56e2\\u961f\",\"width\":\"2\",\"display\":\"1\"}', 'thinkphp', '0.1', '1379512022', '0');
INSERT INTO `onethink_addons` VALUES ('4', 'SystemInfo', '系统环境信息', '用于显示一些服务器的信息', '1', '{\"title\":\"\\u7cfb\\u7edf\\u4fe1\\u606f\",\"width\":\"2\",\"display\":\"1\"}', 'thinkphp', '0.1', '1379512036', '0');
INSERT INTO `onethink_addons` VALUES ('5', 'Editor', '前台编辑器', '用于增强整站长文本的输入和显示', '1', '{\"editor_type\":\"2\",\"editor_wysiwyg\":\"1\",\"editor_height\":\"300px\",\"editor_resize_type\":\"1\"}', 'thinkphp', '0.1', '1379830910', '0');
INSERT INTO `onethink_addons` VALUES ('6', 'Attachment', '附件', '用于文档模型上传附件', '1', 'null', 'thinkphp', '0.1', '1379842319', '1');
INSERT INTO `onethink_addons` VALUES ('9', 'SocialComment', '通用社交化评论', '集成了各种社交化评论插件，轻松集成到系统中。', '1', '{\"comment_type\":\"1\",\"comment_uid_youyan\":\"\",\"comment_short_name_duoshuo\":\"\",\"comment_data_list_duoshuo\":\"\"}', 'thinkphp', '0.1', '1380273962', '0');

-- -----------------------------
-- Table structure for `onethink_attachment`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_attachment`;
CREATE TABLE `onethink_attachment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `title` char(30) NOT NULL DEFAULT '' COMMENT '附件显示名',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '附件类型',
  `source` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '资源ID',
  `record_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '关联记录ID',
  `download` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '下载次数',
  `size` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '附件大小',
  `dir` int(12) unsigned NOT NULL DEFAULT '0' COMMENT '上级目录ID',
  `sort` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`),
  KEY `idx_record_status` (`record_id`,`status`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='附件表';


-- -----------------------------
-- Table structure for `onethink_attribute`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_attribute`;
CREATE TABLE `onethink_attribute` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '字段名',
  `title` varchar(100) NOT NULL DEFAULT '' COMMENT '字段注释',
  `field` varchar(100) NOT NULL DEFAULT '' COMMENT '字段定义',
  `type` varchar(20) NOT NULL DEFAULT '' COMMENT '数据类型',
  `value` varchar(100) NOT NULL DEFAULT '' COMMENT '字段默认值',
  `remark` varchar(100) NOT NULL DEFAULT '' COMMENT '备注',
  `is_show` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '是否显示',
  `extra` varchar(255) NOT NULL DEFAULT '' COMMENT '参数',
  `model_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '模型id',
  `is_must` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否必填',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `validate_rule` varchar(255) NOT NULL,
  `validate_time` tinyint(1) unsigned NOT NULL,
  `error_info` varchar(100) NOT NULL,
  `validate_type` varchar(25) NOT NULL,
  `auto_rule` varchar(100) NOT NULL,
  `auto_time` tinyint(1) unsigned NOT NULL,
  `auto_type` varchar(25) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `model_id` (`model_id`)
) ENGINE=MyISAM AUTO_INCREMENT=49 DEFAULT CHARSET=utf8 COMMENT='模型属性表';

-- -----------------------------
-- Records of `onethink_attribute`
-- -----------------------------
INSERT INTO `onethink_attribute` VALUES ('1', 'uid', '用户ID', 'int(10) unsigned NOT NULL ', 'num', '0', '', '0', '', '1', '0', '1', '1384508362', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('2', 'name', '标识', 'char(40) NOT NULL ', 'string', '', '同一根节点下标识不重复', '0', '', '1', '0', '1', '1453187373', '1383891233', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `onethink_attribute` VALUES ('3', 'title', '标题', 'char(80) NOT NULL ', 'string', '', '文档标题', '1', '', '1', '0', '1', '1453187981', '1383891233', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `onethink_attribute` VALUES ('4', 'category_id', '所属分类', 'int(10) unsigned NOT NULL ', 'string', '', '', '0', '', '1', '0', '1', '1384508336', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('47', 'bivImgs', '营地图片展示', 'varchar(255) NOT NULL', 'uploadpics', '', '', '1', '', '4', '0', '1', '1453186201', '1453186201', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `onethink_attribute` VALUES ('6', 'root', '根节点', 'int(10) unsigned NOT NULL ', 'num', '0', '该文档的顶级文档编号', '0', '', '1', '0', '1', '1384508323', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('7', 'pid', '所属ID', 'int(10) unsigned NOT NULL ', 'num', '0', '父文档编号', '0', '', '1', '0', '1', '1384508543', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('8', 'model_id', '内容模型ID', 'tinyint(3) unsigned NOT NULL ', 'num', '0', '该文档所对应的模型', '0', '', '1', '0', '1', '1384508350', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('9', 'type', '内容类型', 'tinyint(3) unsigned NOT NULL ', 'select', '2', '', '1', '1:目录\r\n2:主题\r\n3:段落', '1', '0', '1', '1384511157', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('10', 'position', '推荐位', 'smallint(5) unsigned NOT NULL ', 'checkbox', '0', '多个推荐则将其推荐值相加', '0', '1:列表推荐\r\n2:频道页推荐\r\n4:首页推荐', '1', '0', '1', '1453185420', '1383891233', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `onethink_attribute` VALUES ('11', 'link_id', '外链', 'int(10) unsigned NOT NULL ', 'num', '0', '0-非外链，大于0-外链ID,需要函数进行链接与编号的转换', '0', '', '1', '0', '1', '1453185399', '1383891233', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `onethink_attribute` VALUES ('12', 'cover_id', '封面', 'int(10) unsigned NOT NULL ', 'picture', '0', '0-无封面，大于0-封面图片ID，需要函数处理', '0', '', '1', '0', '1', '1453185389', '1383891233', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `onethink_attribute` VALUES ('13', 'display', '可见性', 'tinyint(3) unsigned NOT NULL ', 'radio', '1', '', '0', '0:不可见\r\n1:所有人可见', '1', '0', '1', '1453185165', '1383891233', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `onethink_attribute` VALUES ('14', 'deadline', '截至时间', 'int(10) unsigned NOT NULL ', 'datetime', '0', '0-永久有效', '0', '', '1', '0', '1', '1453185301', '1383891233', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `onethink_attribute` VALUES ('15', 'attach', '附件数量', 'tinyint(3) unsigned NOT NULL ', 'num', '0', '', '0', '', '1', '0', '1', '1387260355', '1383891233', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `onethink_attribute` VALUES ('16', 'view', '浏览量', 'int(10) unsigned NOT NULL ', 'num', '0', '', '0', '', '1', '0', '1', '1453185319', '1383891233', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `onethink_attribute` VALUES ('17', 'comment', '评论数', 'int(10) unsigned NOT NULL ', 'num', '0', '', '0', '', '1', '0', '1', '1453183652', '1383891233', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `onethink_attribute` VALUES ('18', 'extend', '扩展统计字段', 'int(10) unsigned NOT NULL ', 'num', '0', '根据需求自行使用', '0', '', '1', '0', '1', '1384508264', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('19', 'level', '优先级', 'int(10) unsigned NOT NULL ', 'num', '0', '越高排序越靠前', '0', '', '1', '0', '1', '1453185345', '1383891233', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `onethink_attribute` VALUES ('20', 'create_time', '创建时间', 'int(10) unsigned NOT NULL ', 'datetime', '0', '', '2', '', '1', '0', '1', '1453185358', '1383891233', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `onethink_attribute` VALUES ('21', 'update_time', '更新时间', 'int(10) unsigned NOT NULL ', 'datetime', '0', '', '3', '', '1', '0', '1', '1453185371', '1383891233', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `onethink_attribute` VALUES ('22', 'status', '数据状态', 'tinyint(4) NOT NULL ', 'radio', '0', '', '0', '-1:删除\r\n0:禁用\r\n1:正常\r\n2:待审核\r\n3:草稿', '1', '0', '1', '1384508496', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('23', 'parse', '内容解析类型', 'tinyint(3) unsigned NOT NULL ', 'select', '0', '', '0', '0:html\r\n1:ubb\r\n2:markdown', '2', '0', '1', '1384511049', '1383891243', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('24', 'content', '文章内容', 'text NOT NULL ', 'editor', '', '', '1', '', '2', '0', '1', '1383896225', '1383891243', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('25', 'template', '详情页显示模板', 'varchar(100) NOT NULL ', 'string', '', '参照display方法参数的定义', '1', '', '2', '0', '1', '1383896190', '1383891243', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('26', 'bookmark', '收藏数', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '2', '0', '1', '1383896103', '1383891243', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('27', 'parse', '内容解析类型', 'tinyint(3) unsigned NOT NULL ', 'select', '0', '', '0', '0:html\r\n1:ubb\r\n2:markdown', '3', '0', '1', '1387260461', '1383891252', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `onethink_attribute` VALUES ('28', 'content', '下载详细描述', 'text NOT NULL ', 'editor', '', '', '1', '', '3', '0', '1', '1383896438', '1383891252', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('29', 'template', '详情页显示模板', 'varchar(100) NOT NULL ', 'string', '', '', '1', '', '3', '0', '1', '1383896429', '1383891252', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('30', 'file_id', '文件ID', 'int(10) unsigned NOT NULL ', 'file', '0', '需要函数处理', '1', '', '3', '0', '1', '1383896415', '1383891252', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('31', 'download', '下载次数', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '3', '0', '1', '1383896380', '1383891252', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('32', 'size', '文件大小', 'bigint(20) unsigned NOT NULL ', 'num', '0', '单位bit', '1', '', '3', '0', '1', '1383896371', '1383891252', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('45', 'bivName', '营地名称', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '4', '0', '1', '1453184170', '1453184170', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `onethink_attribute` VALUES ('34', 'content', '营地信息详情', 'text NOT NULL', 'editor', '', '介绍营地环境等相关信息', '1', '', '4', '0', '1', '1453172157', '1453172157', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `onethink_attribute` VALUES ('44', 'bivAdd', '营地具体地址', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '4', '0', '1', '1453184057', '1453184057', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `onethink_attribute` VALUES ('36', 'bivFood', '美食介绍', 'text NOT NULL', 'editor', '', '', '1', '', '4', '0', '1', '1453172349', '1453172349', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `onethink_attribute` VALUES ('37', 'bivHouse', '住宿描述', 'text NOT NULL', 'editor', '', '', '1', '', '4', '0', '1', '1453172381', '1453172381', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `onethink_attribute` VALUES ('38', 'bivType', '营地类型', 'char(50) NOT NULL', 'select', '', '作为营地类型搜索标签', '1', '1:湖畔型\r\n2:海滨型\r\n3:丛林型\r\n4:乡村型\r\n5:草原型', '4', '1', '1', '1453172764', '1453172764', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `onethink_attribute` VALUES ('39', 'campType', '露营类型', 'char(50) NOT NULL', 'select', '作为露营方式的搜索标签', '', '1', '1:帐篷型\r\n2:树屋\r\n3:草棚', '4', '1', '1', '1453172902', '1453172902', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `onethink_attribute` VALUES ('46', 'bivImg', '首页图片', 'int(10) UNSIGNED NOT NULL', 'picture', '', '', '1', '', '4', '0', '1', '1453184993', '1453184336', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `onethink_attribute` VALUES ('41', 'gamesBg', '游戏设置背景', 'text NOT NULL', 'textarea', '', '游戏背景描述', '1', '', '4', '1', '1', '1453173300', '1453173300', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `onethink_attribute` VALUES ('42', 'gameDes', '游戏规则描述', 'text NOT NULL', 'textarea', '', '', '1', '', '4', '0', '1', '1453179455', '1453179455', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `onethink_attribute` VALUES ('43', 'campSafety', '安全须知', 'text NOT NULL', 'textarea', '', '', '1', '', '4', '1', '1', '1453183260', '1453183260', '', '3', '', 'regex', '', '3', 'function');

-- -----------------------------
-- Table structure for `onethink_attribute2`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_attribute2`;
CREATE TABLE `onethink_attribute2` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '字段名',
  `title` varchar(100) NOT NULL DEFAULT '' COMMENT '字段注释',
  `field` varchar(100) NOT NULL DEFAULT '' COMMENT '字段定义',
  `type` varchar(20) NOT NULL DEFAULT '' COMMENT '数据类型',
  `value` varchar(100) NOT NULL DEFAULT '' COMMENT '字段默认值',
  `remark` varchar(100) NOT NULL DEFAULT '' COMMENT '备注',
  `is_show` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '是否显示',
  `extra` varchar(255) NOT NULL DEFAULT '' COMMENT '参数',
  `model_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '模型id',
  `is_must` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否必填',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `validate_rule` varchar(255) NOT NULL,
  `validate_time` tinyint(1) unsigned NOT NULL,
  `error_info` varchar(100) NOT NULL,
  `validate_type` varchar(25) NOT NULL,
  `auto_rule` varchar(100) NOT NULL,
  `auto_time` tinyint(1) unsigned NOT NULL,
  `auto_type` varchar(25) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `model_id` (`model_id`)
) ENGINE=MyISAM AUTO_INCREMENT=36 DEFAULT CHARSET=utf8 COMMENT='模型属性表';

-- -----------------------------
-- Records of `onethink_attribute2`
-- -----------------------------
INSERT INTO `onethink_attribute2` VALUES ('1', 'uid', '用户ID', 'int(10) unsigned NOT NULL ', 'num', '0', '', '0', '', '1', '0', '1', '1384508362', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute2` VALUES ('2', 'bivAdd', '营地所在地址', 'char(40) NOT NULL ', 'string', '', '详细地址', '1', '', '1', '0', '1', '1383894743', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute2` VALUES ('3', 'bivName', '露营地名称', 'char(80) NOT NULL ', 'string', '', '露营所在地', '1', '', '1', '0', '1', '1383894778', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute2` VALUES ('4', 'category_id', '所属分类', 'int(10) unsigned NOT NULL ', 'string', '', '', '0', '', '1', '0', '1', '1384508336', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute2` VALUES ('33', 'bivFood', '美食描述', 'char(140) NOT NULL ', 'textarea', '', '', '1', '', '1', '0', '1', '1383894927', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute2` VALUES ('6', 'root', '根节点', 'int(10) unsigned NOT NULL ', 'num', '0', '该文档的顶级文档编号', '0', '', '1', '0', '1', '1384508323', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute2` VALUES ('7', 'pid', '所属ID', 'int(10) unsigned NOT NULL ', 'num', '0', '父文档编号', '0', '', '1', '0', '1', '1384508543', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute2` VALUES ('8', 'model_id', '内容模型ID', 'tinyint(3) unsigned NOT NULL ', 'num', '0', '该文档所对应的模型', '0', '', '1', '0', '1', '1384508350', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute2` VALUES ('9', 'bivType', '营地类型', 'tinyint(3) unsigned NOT NULL ', 'select', '2', '', '1', '1:目录\r\n2:主题\r\n1:海滨型,2:乡村型,3:草原型,4:湖畔型', '1', '0', '1', '1384511157', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute2` VALUES ('10', 'position', '推荐位', 'smallint(5) unsigned NOT NULL ', 'checkbox', '0', '多个推荐则将其推荐值相加', '1', '1:列表推荐\r\n2:频道页推荐\r\n4:首页推荐', '1', '0', '1', '1383895640', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute2` VALUES ('11', 'link_id', '外链', 'int(10) unsigned NOT NULL ', 'num', '0', '0-非外链，大于0-外链ID,需要函数进行链接与编号的转换', '1', '', '1', '0', '1', '1383895757', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute2` VALUES ('12', 'cover_id', '封面', 'int(10) unsigned NOT NULL ', 'picture', '0', '0-无封面，大于0-封面图片ID，需要函数处理', '1', '', '1', '0', '1', '1384147827', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute2` VALUES ('13', 'display', '可见性', 'tinyint(3) unsigned NOT NULL ', 'radio', '1', '', '1', '0:不可见\r\n1:所有人可见', '1', '0', '1', '1386662271', '1383891233', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `onethink_attribute2` VALUES ('14', 'deadline', '截至时间', 'int(10) unsigned NOT NULL ', 'datetime', '0', '0-永久有效', '1', '', '1', '0', '1', '1387163248', '1383891233', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `onethink_attribute2` VALUES ('15', 'attach', '附件数量', 'tinyint(3) unsigned NOT NULL ', 'num', '0', '', '0', '', '1', '0', '1', '1387260355', '1383891233', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `onethink_attribute2` VALUES ('16', 'view', '浏览量', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '1', '0', '1', '1383895835', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute2` VALUES ('17', 'comment', '评论数', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '1', '0', '1', '1383895846', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute2` VALUES ('18', 'extend', '扩展统计字段', 'int(10) unsigned NOT NULL ', 'num', '0', '根据需求自行使用', '0', '', '1', '0', '1', '1384508264', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute2` VALUES ('19', 'level', '优先级', 'int(10) unsigned NOT NULL ', 'num', '0', '越高排序越靠前', '1', '', '1', '0', '1', '1383895894', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute2` VALUES ('20', 'create_time', '创建时间', 'int(10) unsigned NOT NULL ', 'datetime', '0', '', '1', '', '1', '0', '1', '1383895903', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute2` VALUES ('21', 'update_time', '更新时间', 'int(10) unsigned NOT NULL ', 'datetime', '0', '', '0', '', '1', '0', '1', '1384508277', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute2` VALUES ('22', 'status', '数据状态', 'tinyint(4) NOT NULL ', 'radio', '0', '', '0', '-1:删除\r\n0:禁用\r\n1:正常\r\n2:待审核\r\n3:草稿', '1', '0', '1', '1384508496', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute2` VALUES ('23', 'parse', '内容解析类型', 'tinyint(3) unsigned NOT NULL ', 'select', '0', '', '0', '0:html\r\n1:ubb\r\n2:markdown', '2', '0', '1', '1384511049', '1383891243', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute2` VALUES ('24', 'content', '文章内容', 'text NOT NULL ', 'editor', '', '', '1', '', '2', '0', '1', '1383896225', '1383891243', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute2` VALUES ('25', 'template', '详情页显示模板', 'varchar(100) NOT NULL ', 'string', '', '参照display方法参数的定义', '1', '', '2', '0', '1', '1383896190', '1383891243', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute2` VALUES ('26', 'bookmark', '收藏数', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '2', '0', '1', '1383896103', '1383891243', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute2` VALUES ('27', 'parse', '内容解析类型', 'tinyint(3) unsigned NOT NULL ', 'select', '0', '', '0', '0:html\r\n1:ubb\r\n2:markdown', '3', '0', '1', '1387260461', '1383891252', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `onethink_attribute2` VALUES ('28', 'content', '下载详细描述', 'text NOT NULL ', 'editor', '', '', '1', '', '3', '0', '1', '1383896438', '1383891252', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute2` VALUES ('29', 'template', '详情页显示模板', 'varchar(100) NOT NULL ', 'string', '', '', '1', '', '3', '0', '1', '1383896429', '1383891252', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute2` VALUES ('30', 'file_id', '文件ID', 'int(10) unsigned NOT NULL ', 'file', '0', '需要函数处理', '1', '', '3', '0', '1', '1383896415', '1383891252', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute2` VALUES ('31', 'download', '下载次数', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '3', '0', '1', '1383896380', '1383891252', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute2` VALUES ('32', 'size', '文件大小', 'bigint(20) unsigned NOT NULL ', 'num', '0', '单位bit', '1', '', '3', '0', '1', '1383896371', '1383891252', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute2` VALUES ('5', 'bivHouse', '住宿描述', 'char(140)  NOT  NULL', 'textarea', '', '', '1', '', '1', '0', '1', '1601171427', '1601171627', ' ', '0', ' ', ' ', ' ', '0', ' ');
INSERT INTO `onethink_attribute2` VALUES ('34', 'campType', '露营方式', 'tinyint(3) unsigned  NOT  NULL', 'select', '2', '', '1', '1:房车,2:帐篷,3:树屋,4:草棚', '1', '0', '1', '1601171512', '1601171520', ' ', '0', ' ', ' ', ' ', '0', ' ');
INSERT INTO `onethink_attribute2` VALUES ('35', 'pictures', '批量上传图片', 'int(10) UNSIGNED NOT NULL', 'picture', '', '', '1', '', '1', '0', '1', '1453027951', '1453027951', '', '3', '', 'regex', '', '3', 'function');

-- -----------------------------
-- Table structure for `onethink_attribute_copy1`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_attribute_copy1`;
CREATE TABLE `onethink_attribute_copy1` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '字段名',
  `title` varchar(100) NOT NULL DEFAULT '' COMMENT '字段注释',
  `field` varchar(100) NOT NULL DEFAULT '' COMMENT '字段定义',
  `type` varchar(20) NOT NULL DEFAULT '' COMMENT '数据类型',
  `value` varchar(100) NOT NULL DEFAULT '' COMMENT '字段默认值',
  `remark` varchar(100) NOT NULL DEFAULT '' COMMENT '备注',
  `is_show` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '是否显示',
  `extra` varchar(255) NOT NULL DEFAULT '' COMMENT '参数',
  `model_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '模型id',
  `is_must` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否必填',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `validate_rule` varchar(255) NOT NULL,
  `validate_time` tinyint(1) unsigned NOT NULL,
  `error_info` varchar(100) NOT NULL,
  `validate_type` varchar(25) NOT NULL,
  `auto_rule` varchar(100) NOT NULL,
  `auto_time` tinyint(1) unsigned NOT NULL,
  `auto_type` varchar(25) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `model_id` (`model_id`)
) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=utf8 COMMENT='模型属性表';

-- -----------------------------
-- Records of `onethink_attribute_copy1`
-- -----------------------------
INSERT INTO `onethink_attribute_copy1` VALUES ('1', 'uid', '用户ID', 'int(10) unsigned NOT NULL ', 'num', '0', '', '0', '', '1', '0', '1', '1384508362', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute_copy1` VALUES ('2', 'name', '标识', 'char(40) NOT NULL ', 'string', '', '同一根节点下标识不重复', '1', '', '1', '0', '1', '1383894743', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute_copy1` VALUES ('3', 'title', '标题', 'char(80) NOT NULL ', 'string', '', '文档标题', '1', '', '1', '0', '1', '1383894778', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute_copy1` VALUES ('4', 'category_id', '所属分类', 'int(10) unsigned NOT NULL ', 'string', '', '', '0', '', '1', '0', '1', '1384508336', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute_copy1` VALUES ('5', 'description', '描述', 'char(140) NOT NULL ', 'textarea', '', '', '1', '', '1', '0', '1', '1383894927', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute_copy1` VALUES ('6', 'root', '根节点', 'int(10) unsigned NOT NULL ', 'num', '0', '该文档的顶级文档编号', '0', '', '1', '0', '1', '1384508323', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute_copy1` VALUES ('7', 'pid', '所属ID', 'int(10) unsigned NOT NULL ', 'num', '0', '父文档编号', '0', '', '1', '0', '1', '1384508543', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute_copy1` VALUES ('8', 'model_id', '内容模型ID', 'tinyint(3) unsigned NOT NULL ', 'num', '0', '该文档所对应的模型', '0', '', '1', '0', '1', '1384508350', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute_copy1` VALUES ('9', 'type', '内容类型', 'tinyint(3) unsigned NOT NULL ', 'select', '2', '', '1', '1:目录\r\n2:主题\r\n3:段落', '1', '0', '1', '1384511157', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute_copy1` VALUES ('10', 'position', '推荐位', 'smallint(5) unsigned NOT NULL ', 'checkbox', '0', '多个推荐则将其推荐值相加', '1', '1:列表推荐\r\n2:频道页推荐\r\n4:首页推荐', '1', '0', '1', '1383895640', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute_copy1` VALUES ('11', 'link_id', '外链', 'int(10) unsigned NOT NULL ', 'num', '0', '0-非外链，大于0-外链ID,需要函数进行链接与编号的转换', '1', '', '1', '0', '1', '1383895757', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute_copy1` VALUES ('12', 'cover_id', '封面', 'int(10) unsigned NOT NULL ', 'picture', '0', '0-无封面，大于0-封面图片ID，需要函数处理', '1', '', '1', '0', '1', '1384147827', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute_copy1` VALUES ('13', 'display', '可见性', 'tinyint(3) unsigned NOT NULL ', 'radio', '1', '', '1', '0:不可见\r\n1:所有人可见', '1', '0', '1', '1386662271', '1383891233', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `onethink_attribute_copy1` VALUES ('14', 'deadline', '截至时间', 'int(10) unsigned NOT NULL ', 'datetime', '0', '0-永久有效', '1', '', '1', '0', '1', '1387163248', '1383891233', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `onethink_attribute_copy1` VALUES ('15', 'attach', '附件数量', 'tinyint(3) unsigned NOT NULL ', 'num', '0', '', '0', '', '1', '0', '1', '1387260355', '1383891233', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `onethink_attribute_copy1` VALUES ('16', 'view', '浏览量', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '1', '0', '1', '1383895835', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute_copy1` VALUES ('17', 'comment', '评论数', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '1', '0', '1', '1383895846', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute_copy1` VALUES ('18', 'extend', '扩展统计字段', 'int(10) unsigned NOT NULL ', 'num', '0', '根据需求自行使用', '0', '', '1', '0', '1', '1384508264', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute_copy1` VALUES ('19', 'level', '优先级', 'int(10) unsigned NOT NULL ', 'num', '0', '越高排序越靠前', '1', '', '1', '0', '1', '1383895894', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute_copy1` VALUES ('20', 'create_time', '创建时间', 'int(10) unsigned NOT NULL ', 'datetime', '0', '', '1', '', '1', '0', '1', '1383895903', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute_copy1` VALUES ('21', 'update_time', '更新时间', 'int(10) unsigned NOT NULL ', 'datetime', '0', '', '0', '', '1', '0', '1', '1384508277', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute_copy1` VALUES ('22', 'status', '数据状态', 'tinyint(4) NOT NULL ', 'radio', '0', '', '0', '-1:删除\r\n0:禁用\r\n1:正常\r\n2:待审核\r\n3:草稿', '1', '0', '1', '1384508496', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute_copy1` VALUES ('23', 'parse', '内容解析类型', 'tinyint(3) unsigned NOT NULL ', 'select', '0', '', '0', '0:html\r\n1:ubb\r\n2:markdown', '2', '0', '1', '1384511049', '1383891243', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute_copy1` VALUES ('24', 'content', '文章内容', 'text NOT NULL ', 'editor', '', '', '1', '', '2', '0', '1', '1383896225', '1383891243', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute_copy1` VALUES ('25', 'template', '详情页显示模板', 'varchar(100) NOT NULL ', 'string', '', '参照display方法参数的定义', '1', '', '2', '0', '1', '1383896190', '1383891243', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute_copy1` VALUES ('26', 'bookmark', '收藏数', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '2', '0', '1', '1383896103', '1383891243', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute_copy1` VALUES ('27', 'parse', '内容解析类型', 'tinyint(3) unsigned NOT NULL ', 'select', '0', '', '0', '0:html\r\n1:ubb\r\n2:markdown', '3', '0', '1', '1387260461', '1383891252', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `onethink_attribute_copy1` VALUES ('28', 'content', '下载详细描述', 'text NOT NULL ', 'editor', '', '', '1', '', '3', '0', '1', '1383896438', '1383891252', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute_copy1` VALUES ('29', 'template', '详情页显示模板', 'varchar(100) NOT NULL ', 'string', '', '', '1', '', '3', '0', '1', '1383896429', '1383891252', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute_copy1` VALUES ('30', 'file_id', '文件ID', 'int(10) unsigned NOT NULL ', 'file', '0', '需要函数处理', '1', '', '3', '0', '1', '1383896415', '1383891252', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute_copy1` VALUES ('31', 'download', '下载次数', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '3', '0', '1', '1383896380', '1383891252', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute_copy1` VALUES ('32', 'size', '文件大小', 'bigint(20) unsigned NOT NULL ', 'num', '0', '单位bit', '1', '', '3', '0', '1', '1383896371', '1383891252', '', '0', '', '', '', '0', '');

-- -----------------------------
-- Table structure for `onethink_auth_extend`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_auth_extend`;
CREATE TABLE `onethink_auth_extend` (
  `group_id` mediumint(10) unsigned NOT NULL COMMENT '用户id',
  `extend_id` mediumint(8) unsigned NOT NULL COMMENT '扩展表中数据的id',
  `type` tinyint(1) unsigned NOT NULL COMMENT '扩展类型标识 1:栏目分类权限;2:模型权限',
  UNIQUE KEY `group_extend_type` (`group_id`,`extend_id`,`type`),
  KEY `uid` (`group_id`),
  KEY `group_id` (`extend_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='用户组与分类的对应关系表';

-- -----------------------------
-- Records of `onethink_auth_extend`
-- -----------------------------
INSERT INTO `onethink_auth_extend` VALUES ('1', '1', '1');
INSERT INTO `onethink_auth_extend` VALUES ('1', '1', '2');
INSERT INTO `onethink_auth_extend` VALUES ('1', '2', '1');
INSERT INTO `onethink_auth_extend` VALUES ('1', '2', '2');
INSERT INTO `onethink_auth_extend` VALUES ('1', '3', '1');
INSERT INTO `onethink_auth_extend` VALUES ('1', '3', '2');
INSERT INTO `onethink_auth_extend` VALUES ('1', '4', '1');
INSERT INTO `onethink_auth_extend` VALUES ('1', '37', '1');

-- -----------------------------
-- Table structure for `onethink_auth_group`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_auth_group`;
CREATE TABLE `onethink_auth_group` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户组id,自增主键',
  `module` varchar(20) NOT NULL COMMENT '用户组所属模块',
  `type` tinyint(4) NOT NULL COMMENT '组类型',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '用户组中文名称',
  `description` varchar(80) NOT NULL DEFAULT '' COMMENT '描述信息',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '用户组状态：为1正常，为0禁用,-1为删除',
  `rules` varchar(500) NOT NULL DEFAULT '' COMMENT '用户组拥有的规则id，多个规则 , 隔开',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `onethink_auth_group`
-- -----------------------------
INSERT INTO `onethink_auth_group` VALUES ('1', 'admin', '1', '管理员', '', '1', '1,2,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,79,80,81,82,83,84,86,87,88,89,90,91,92,93,94,95,96,97,100,102,103,105,106');
INSERT INTO `onethink_auth_group` VALUES ('2', 'admin', '1', '测试用户', '测试用户', '1', '1,2,5,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,79,80,82,83,84,88,89,90,91,92,93,96,97,100,102,103,195');
INSERT INTO `onethink_auth_group` VALUES ('3', 'admin', '1', '代理人', '', '1', '1,227,228,229,230,231,232,233,234,237,238,239,241,242,243');
INSERT INTO `onethink_auth_group` VALUES ('4', 'admin', '1', '消费者', '', '1', '1');

-- -----------------------------
-- Table structure for `onethink_auth_group_access`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_auth_group_access`;
CREATE TABLE `onethink_auth_group_access` (
  `uid` int(10) unsigned NOT NULL COMMENT '用户id',
  `group_id` mediumint(8) unsigned NOT NULL COMMENT '用户组id',
  UNIQUE KEY `uid_group_id` (`uid`,`group_id`),
  KEY `uid` (`uid`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `onethink_auth_group_access`
-- -----------------------------
INSERT INTO `onethink_auth_group_access` VALUES ('3', '4');
INSERT INTO `onethink_auth_group_access` VALUES ('4', '4');
INSERT INTO `onethink_auth_group_access` VALUES ('5', '4');
INSERT INTO `onethink_auth_group_access` VALUES ('6', '4');
INSERT INTO `onethink_auth_group_access` VALUES ('7', '3');
INSERT INTO `onethink_auth_group_access` VALUES ('8', '3');
INSERT INTO `onethink_auth_group_access` VALUES ('9', '3');

-- -----------------------------
-- Table structure for `onethink_auth_rule`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_auth_rule`;
CREATE TABLE `onethink_auth_rule` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '规则id,自增主键',
  `module` varchar(20) NOT NULL COMMENT '规则所属module',
  `type` tinyint(2) NOT NULL DEFAULT '1' COMMENT '1-url;2-主菜单',
  `name` char(80) NOT NULL DEFAULT '' COMMENT '规则唯一英文标识',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '规则中文描述',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否有效(0:无效,1:有效)',
  `condition` varchar(300) NOT NULL DEFAULT '' COMMENT '规则附加条件',
  PRIMARY KEY (`id`),
  KEY `module` (`module`,`status`,`type`)
) ENGINE=MyISAM AUTO_INCREMENT=246 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `onethink_auth_rule`
-- -----------------------------
INSERT INTO `onethink_auth_rule` VALUES ('1', 'admin', '2', 'Admin/Index/index', '首页', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('2', 'admin', '2', 'Admin/Article/mydocument', '内容', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('3', 'admin', '2', 'Admin/User/index', '用户', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('4', 'admin', '2', 'Admin/Addons/index', '扩展', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('5', 'admin', '2', 'Admin/Config/group', '系统', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('7', 'admin', '1', 'Admin/article/add', '新增', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('8', 'admin', '1', 'Admin/article/edit', '编辑', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('9', 'admin', '1', 'Admin/article/setStatus', '改变状态', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('10', 'admin', '1', 'Admin/article/update', '保存', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('11', 'admin', '1', 'Admin/article/autoSave', '保存草稿', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('12', 'admin', '1', 'Admin/article/move', '移动', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('13', 'admin', '1', 'Admin/article/copy', '复制', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('14', 'admin', '1', 'Admin/article/paste', '粘贴', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('15', 'admin', '1', 'Admin/article/permit', '还原', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('16', 'admin', '1', 'Admin/article/clear', '清空', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('17', 'admin', '1', 'Admin/article/index', '文档列表', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('18', 'admin', '1', 'Admin/article/recycle', '回收站', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('19', 'admin', '1', 'Admin/User/addaction', '新增用户行为', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('20', 'admin', '1', 'Admin/User/editaction', '编辑用户行为', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('21', 'admin', '1', 'Admin/User/saveAction', '保存用户行为', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('22', 'admin', '1', 'Admin/User/setStatus', '变更行为状态', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('23', 'admin', '1', 'Admin/User/changeStatus?method=forbidUser', '禁用会员', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('24', 'admin', '1', 'Admin/User/changeStatus?method=resumeUser', '启用会员', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('25', 'admin', '1', 'Admin/User/changeStatus?method=deleteUser', '删除会员', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('26', 'admin', '1', 'Admin/User/index', '消费者权限', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('27', 'admin', '1', 'Admin/User/action', '用户行为', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('28', 'admin', '1', 'Admin/AuthManager/changeStatus?method=deleteGroup', '删除', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('29', 'admin', '1', 'Admin/AuthManager/changeStatus?method=forbidGroup', '禁用', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('30', 'admin', '1', 'Admin/AuthManager/changeStatus?method=resumeGroup', '恢复', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('31', 'admin', '1', 'Admin/AuthManager/createGroup', '新增', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('32', 'admin', '1', 'Admin/AuthManager/editGroup', '编辑', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('33', 'admin', '1', 'Admin/AuthManager/writeGroup', '保存用户组', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('34', 'admin', '1', 'Admin/AuthManager/group', '授权', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('35', 'admin', '1', 'Admin/AuthManager/access', '访问授权', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('36', 'admin', '1', 'Admin/AuthManager/user', '成员授权', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('37', 'admin', '1', 'Admin/AuthManager/removeFromGroup', '解除授权', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('38', 'admin', '1', 'Admin/AuthManager/addToGroup', '保存成员授权', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('39', 'admin', '1', 'Admin/AuthManager/category', '分类授权', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('40', 'admin', '1', 'Admin/AuthManager/addToCategory', '保存分类授权', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('41', 'admin', '1', 'Admin/AuthManager/index', '权限管理', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('42', 'admin', '1', 'Admin/Addons/create', '创建', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('43', 'admin', '1', 'Admin/Addons/checkForm', '检测创建', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('44', 'admin', '1', 'Admin/Addons/preview', '预览', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('45', 'admin', '1', 'Admin/Addons/build', '快速生成插件', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('46', 'admin', '1', 'Admin/Addons/config', '设置', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('47', 'admin', '1', 'Admin/Addons/disable', '禁用', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('48', 'admin', '1', 'Admin/Addons/enable', '启用', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('49', 'admin', '1', 'Admin/Addons/install', '安装', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('50', 'admin', '1', 'Admin/Addons/uninstall', '卸载', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('51', 'admin', '1', 'Admin/Addons/saveconfig', '更新配置', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('52', 'admin', '1', 'Admin/Addons/adminList', '插件后台列表', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('53', 'admin', '1', 'Admin/Addons/execute', 'URL方式访问插件', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('54', 'admin', '1', 'Admin/Addons/index', '插件管理', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('55', 'admin', '1', 'Admin/Addons/hooks', '钩子管理', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('56', 'admin', '1', 'Admin/model/add', '新增', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('57', 'admin', '1', 'Admin/model/edit', '编辑', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('58', 'admin', '1', 'Admin/model/setStatus', '改变状态', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('59', 'admin', '1', 'Admin/model/update', '保存数据', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('60', 'admin', '1', 'Admin/Model/index', '模型管理', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('61', 'admin', '1', 'Admin/Config/edit', '编辑', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('62', 'admin', '1', 'Admin/Config/del', '删除', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('63', 'admin', '1', 'Admin/Config/add', '新增', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('64', 'admin', '1', 'Admin/Config/save', '保存', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('65', 'admin', '1', 'Admin/Config/group', '网站设置', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('66', 'admin', '1', 'Admin/Config/index', '配置管理', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('67', 'admin', '1', 'Admin/Channel/add', '新增', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('68', 'admin', '1', 'Admin/Channel/edit', '编辑', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('69', 'admin', '1', 'Admin/Channel/del', '删除', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('70', 'admin', '1', 'Admin/Channel/index', '导航管理', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('71', 'admin', '1', 'Admin/Category/edit', '编辑', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('72', 'admin', '1', 'Admin/Category/add', '新增', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('73', 'admin', '1', 'Admin/Category/remove', '删除', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('74', 'admin', '1', 'Admin/Category/index', '分类管理', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('75', 'admin', '1', 'Admin/file/upload', '上传控件', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('76', 'admin', '1', 'Admin/file/uploadPicture', '上传图片', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('77', 'admin', '1', 'Admin/file/download', '下载', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('94', 'admin', '1', 'Admin/AuthManager/modelauth', '模型授权', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('79', 'admin', '1', 'Admin/article/batchOperate', '导入', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('80', 'admin', '1', 'Admin/Database/index?type=export', '备份数据库', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('81', 'admin', '1', 'Admin/Database/index?type=import', '还原数据库', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('82', 'admin', '1', 'Admin/Database/export', '备份', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('83', 'admin', '1', 'Admin/Database/optimize', '优化表', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('84', 'admin', '1', 'Admin/Database/repair', '修复表', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('86', 'admin', '1', 'Admin/Database/import', '恢复', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('87', 'admin', '1', 'Admin/Database/del', '删除', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('88', 'admin', '1', 'Admin/User/add', '新增用户', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('89', 'admin', '1', 'Admin/Attribute/index', '属性管理', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('90', 'admin', '1', 'Admin/Attribute/add', '新增', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('91', 'admin', '1', 'Admin/Attribute/edit', '编辑', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('92', 'admin', '1', 'Admin/Attribute/setStatus', '改变状态', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('93', 'admin', '1', 'Admin/Attribute/update', '保存数据', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('95', 'admin', '1', 'Admin/AuthManager/addToModel', '保存模型授权', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('96', 'admin', '1', 'Admin/Category/move', '移动', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('97', 'admin', '1', 'Admin/Category/merge', '合并', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('98', 'admin', '1', 'Admin/Config/menu', '后台菜单管理', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('99', 'admin', '1', 'Admin/Article/mydocument', '内容', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('100', 'admin', '1', 'Admin/Menu/index', '菜单管理', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('101', 'admin', '1', 'Admin/other', '其他', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('102', 'admin', '1', 'Admin/Menu/add', '新增', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('103', 'admin', '1', 'Admin/Menu/edit', '编辑', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('104', 'admin', '1', 'Admin/Think/lists?model=article', '文章管理', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('105', 'admin', '1', 'Admin/Think/lists?model=download', '下载管理', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('106', 'admin', '1', 'Admin/Think/lists?model=config', '配置管理', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('107', 'admin', '1', 'Admin/Action/actionlog', '行为日志', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('108', 'admin', '1', 'Admin/User/updatePassword', '修改密码', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('109', 'admin', '1', 'Admin/User/updateNickname', '修改昵称', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('110', 'admin', '1', 'Admin/action/edit', '查看行为日志', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('205', 'admin', '1', 'Admin/think/add', '新增数据', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('111', 'admin', '2', 'Admin/article/index', '文档列表', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('112', 'admin', '2', 'Admin/article/add', '新增', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('113', 'admin', '2', 'Admin/article/edit', '编辑', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('114', 'admin', '2', 'Admin/article/setStatus', '改变状态', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('115', 'admin', '2', 'Admin/article/update', '保存', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('116', 'admin', '2', 'Admin/article/autoSave', '保存草稿', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('117', 'admin', '2', 'Admin/article/move', '移动', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('118', 'admin', '2', 'Admin/article/copy', '复制', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('119', 'admin', '2', 'Admin/article/paste', '粘贴', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('120', 'admin', '2', 'Admin/article/batchOperate', '导入', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('121', 'admin', '2', 'Admin/article/recycle', '回收站', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('122', 'admin', '2', 'Admin/article/permit', '还原', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('123', 'admin', '2', 'Admin/article/clear', '清空', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('124', 'admin', '2', 'Admin/User/add', '新增用户', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('125', 'admin', '2', 'Admin/User/action', '用户行为', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('126', 'admin', '2', 'Admin/User/addAction', '新增用户行为', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('127', 'admin', '2', 'Admin/User/editAction', '编辑用户行为', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('128', 'admin', '2', 'Admin/User/saveAction', '保存用户行为', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('129', 'admin', '2', 'Admin/User/setStatus', '变更行为状态', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('130', 'admin', '2', 'Admin/User/changeStatus?method=forbidUser', '禁用会员', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('131', 'admin', '2', 'Admin/User/changeStatus?method=resumeUser', '启用会员', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('132', 'admin', '2', 'Admin/User/changeStatus?method=deleteUser', '删除会员', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('133', 'admin', '2', 'Admin/AuthManager/index', '权限管理', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('134', 'admin', '2', 'Admin/AuthManager/changeStatus?method=deleteGroup', '删除', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('135', 'admin', '2', 'Admin/AuthManager/changeStatus?method=forbidGroup', '禁用', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('136', 'admin', '2', 'Admin/AuthManager/changeStatus?method=resumeGroup', '恢复', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('137', 'admin', '2', 'Admin/AuthManager/createGroup', '新增', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('138', 'admin', '2', 'Admin/AuthManager/editGroup', '编辑', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('139', 'admin', '2', 'Admin/AuthManager/writeGroup', '保存用户组', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('140', 'admin', '2', 'Admin/AuthManager/group', '授权', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('141', 'admin', '2', 'Admin/AuthManager/access', '访问授权', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('142', 'admin', '2', 'Admin/AuthManager/user', '成员授权', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('143', 'admin', '2', 'Admin/AuthManager/removeFromGroup', '解除授权', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('144', 'admin', '2', 'Admin/AuthManager/addToGroup', '保存成员授权', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('145', 'admin', '2', 'Admin/AuthManager/category', '分类授权', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('146', 'admin', '2', 'Admin/AuthManager/addToCategory', '保存分类授权', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('147', 'admin', '2', 'Admin/AuthManager/modelauth', '模型授权', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('148', 'admin', '2', 'Admin/AuthManager/addToModel', '保存模型授权', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('149', 'admin', '2', 'Admin/Addons/create', '创建', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('150', 'admin', '2', 'Admin/Addons/checkForm', '检测创建', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('151', 'admin', '2', 'Admin/Addons/preview', '预览', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('152', 'admin', '2', 'Admin/Addons/build', '快速生成插件', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('153', 'admin', '2', 'Admin/Addons/config', '设置', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('154', 'admin', '2', 'Admin/Addons/disable', '禁用', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('155', 'admin', '2', 'Admin/Addons/enable', '启用', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('156', 'admin', '2', 'Admin/Addons/install', '安装', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('157', 'admin', '2', 'Admin/Addons/uninstall', '卸载', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('158', 'admin', '2', 'Admin/Addons/saveconfig', '更新配置', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('159', 'admin', '2', 'Admin/Addons/adminList', '插件后台列表', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('160', 'admin', '2', 'Admin/Addons/execute', 'URL方式访问插件', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('161', 'admin', '2', 'Admin/Addons/hooks', '钩子管理', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('162', 'admin', '2', 'Admin/Model/index', '模型管理', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('163', 'admin', '2', 'Admin/model/add', '新增', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('164', 'admin', '2', 'Admin/model/edit', '编辑', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('165', 'admin', '2', 'Admin/model/setStatus', '改变状态', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('166', 'admin', '2', 'Admin/model/update', '保存数据', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('167', 'admin', '2', 'Admin/Attribute/index', '属性管理', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('168', 'admin', '2', 'Admin/Attribute/add', '新增', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('169', 'admin', '2', 'Admin/Attribute/edit', '编辑', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('170', 'admin', '2', 'Admin/Attribute/setStatus', '改变状态', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('171', 'admin', '2', 'Admin/Attribute/update', '保存数据', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('172', 'admin', '2', 'Admin/Config/index', '配置管理', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('173', 'admin', '2', 'Admin/Config/edit', '编辑', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('174', 'admin', '2', 'Admin/Config/del', '删除', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('175', 'admin', '2', 'Admin/Config/add', '新增', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('176', 'admin', '2', 'Admin/Config/save', '保存', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('177', 'admin', '2', 'Admin/Menu/index', '菜单管理', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('178', 'admin', '2', 'Admin/Channel/index', '导航管理', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('179', 'admin', '2', 'Admin/Channel/add', '新增', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('180', 'admin', '2', 'Admin/Channel/edit', '编辑', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('181', 'admin', '2', 'Admin/Channel/del', '删除', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('182', 'admin', '2', 'Admin/Category/index', '分类管理', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('183', 'admin', '2', 'Admin/Category/edit', '编辑', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('184', 'admin', '2', 'Admin/Category/add', '新增', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('185', 'admin', '2', 'Admin/Category/remove', '删除', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('186', 'admin', '2', 'Admin/Category/move', '移动', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('187', 'admin', '2', 'Admin/Category/merge', '合并', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('188', 'admin', '2', 'Admin/Database/index?type=export', '备份数据库', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('189', 'admin', '2', 'Admin/Database/export', '备份', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('190', 'admin', '2', 'Admin/Database/optimize', '优化表', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('191', 'admin', '2', 'Admin/Database/repair', '修复表', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('192', 'admin', '2', 'Admin/Database/index?type=import', '还原数据库', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('193', 'admin', '2', 'Admin/Database/import', '恢复', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('194', 'admin', '2', 'Admin/Database/del', '删除', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('195', 'admin', '2', 'Admin/other', '其他', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('196', 'admin', '2', 'Admin/Menu/add', '新增', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('197', 'admin', '2', 'Admin/Menu/edit', '编辑', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('198', 'admin', '2', 'Admin/Think/lists?model=article', '应用', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('199', 'admin', '2', 'Admin/Think/lists?model=download', '下载管理', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('200', 'admin', '2', 'Admin/Think/lists?model=config', '应用', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('201', 'admin', '2', 'Admin/Action/actionlog', '行为日志', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('202', 'admin', '2', 'Admin/User/updatePassword', '修改密码', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('203', 'admin', '2', 'Admin/User/updateNickname', '修改昵称', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('204', 'admin', '2', 'Admin/action/edit', '查看行为日志', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('206', 'admin', '1', 'Admin/think/edit', '编辑数据', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('207', 'admin', '1', 'Admin/Menu/import', '导入', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('208', 'admin', '1', 'Admin/Model/generate', '生成', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('209', 'admin', '1', 'Admin/Addons/addHook', '新增钩子', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('210', 'admin', '1', 'Admin/Addons/edithook', '编辑钩子', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('211', 'admin', '1', 'Admin/Article/sort', '文档排序', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('212', 'admin', '1', 'Admin/Config/sort', '排序', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('213', 'admin', '1', 'Admin/Menu/sort', '排序', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('214', 'admin', '1', 'Admin/Channel/sort', '排序', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('215', 'admin', '1', 'Admin/Category/operate/type/move', '移动', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('216', 'admin', '1', 'Admin/Category/operate/type/merge', '合并', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('217', 'admin', '1', 'Admin/Ly/index', '代理人信息', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('218', 'admin', '1', 'Admin/Ly/uindex', '消费者信息', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('219', 'admin', '1', 'Admin/Ly/add', '新增', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('220', 'admin', '1', 'Admin/Ly/update', '编辑', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('221', 'admin', '1', 'Admin/Ly/uadd', '新增', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('222', 'admin', '1', 'Admin/Ly/uedit', '编辑', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('223', 'admin', '1', 'Admin/PerCenter/person', '个人信息', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('224', 'admin', '1', 'Admin/PerCenter/infor', '未读信息', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('225', 'admin', '1', 'Admin/PerCenter/pedit', '编辑', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('226', 'admin', '1', 'Admin/PerCenter/yishenhe', '已审核', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('227', 'admin', '1', 'Admin/AgCamp/clist', '代理中心', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('228', 'admin', '1', 'Admin/AgCamp/cadd', '新增', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('229', 'admin', '1', 'Admin/AgCamp/cupdate', '编辑', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('230', 'admin', '1', 'Admin/AgCamp/cdeletc', '删除', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('231', 'admin', '1', 'Admin/Game/glist', '活动设置', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('232', 'admin', '1', 'Admin/Game/gupdate', '编辑', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('233', 'admin', '1', 'Admin/Game/detail', '游戏信息', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('234', 'admin', '1', 'Admin/Game/gadd', '新增', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('235', 'admin', '2', 'Admin/Ly/index', '用户管理', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('236', 'admin', '2', 'Admin/PerCenter/person', '个人中心', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('237', 'admin', '2', 'Admin/AgCamp/clist', '代理中心', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('238', 'admin', '1', 'Admin/Game/edit', '编辑游戏信息', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('239', 'admin', '1', 'Admin/Game/add', '新增', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('240', 'admin', '2', 'Admin/PerCenter/infor', '个人中心', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('241', 'admin', '1', 'Admin/Sale/index', '营地消费情况', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('242', 'admin', '1', 'Admin/Sale/order', '订单管理', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('243', 'admin', '1', 'Admin/Sale/detail', '查看详情', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('244', 'admin', '1', 'Admin/User/updateXinxi', '完善信息', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('245', 'admin', '1', 'Admin/#', '活动信息', '1', '');

-- -----------------------------
-- Table structure for `onethink_category`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_category`;
CREATE TABLE `onethink_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '分类ID',
  `name` varchar(30) NOT NULL COMMENT '标志',
  `title` varchar(50) NOT NULL COMMENT '标题',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序（同级有效）',
  `list_row` tinyint(3) unsigned NOT NULL DEFAULT '10' COMMENT '列表每页行数',
  `meta_title` varchar(50) NOT NULL DEFAULT '' COMMENT 'SEO的网页标题',
  `keywords` varchar(255) NOT NULL DEFAULT '' COMMENT '关键字',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT '描述',
  `template_index` varchar(100) NOT NULL COMMENT '频道页模板',
  `template_lists` varchar(100) NOT NULL COMMENT '列表页模板',
  `template_detail` varchar(100) NOT NULL COMMENT '详情页模板',
  `template_edit` varchar(100) NOT NULL COMMENT '编辑页模板',
  `model` varchar(100) NOT NULL DEFAULT '' COMMENT '关联模型',
  `type` varchar(100) NOT NULL DEFAULT '' COMMENT '允许发布的内容类型',
  `link_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '外链',
  `allow_publish` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否允许发布内容',
  `display` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '可见性',
  `reply` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否允许回复',
  `check` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '发布的文章是否需要审核',
  `reply_model` varchar(100) NOT NULL DEFAULT '',
  `extend` text NOT NULL COMMENT '扩展设置',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '数据状态',
  `icon` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '分类图标',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=41 DEFAULT CHARSET=utf8 COMMENT='分类表';

-- -----------------------------
-- Records of `onethink_category`
-- -----------------------------
INSERT INTO `onethink_category` VALUES ('1', 'blog', '博客', '0', '0', '10', '', '', '', '', '', '', '', '2', '2,1', '0', '0', '1', '0', '0', '1', '', '1379474947', '1382701539', '1', '0');
INSERT INTO `onethink_category` VALUES ('2', 'default_blog', 'onethink', '1', '1', '10', '', '', '', '', '', '', '', '2', '2,1,3', '0', '1', '1', '0', '1', '1', '', '1379475028', '1453185929', '1', '31');

-- -----------------------------
-- Table structure for `onethink_channel`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_channel`;
CREATE TABLE `onethink_channel` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '频道ID',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级频道ID',
  `title` char(30) NOT NULL COMMENT '频道标题',
  `url` char(100) NOT NULL COMMENT '频道连接',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '导航排序',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态',
  `target` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '新窗口打开',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `onethink_channel`
-- -----------------------------
INSERT INTO `onethink_channel` VALUES ('1', '0', '首页', 'Index/index', '1', '1379475111', '1379923177', '1', '0');
INSERT INTO `onethink_channel` VALUES ('2', '0', '博客', 'Article/index?category=blog', '2', '1379475131', '1379483713', '1', '0');
INSERT INTO `onethink_channel` VALUES ('3', '0', '官网', 'http://www.onethink.cn', '3', '1379475154', '1387163458', '1', '0');

-- -----------------------------
-- Table structure for `onethink_comment`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_comment`;
CREATE TABLE `onethink_comment` (
  `id` mediumint(7) unsigned NOT NULL AUTO_INCREMENT COMMENT '评论ID',
  `aid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文章ID',
  `cid` mediumint(7) unsigned NOT NULL DEFAULT '0' COMMENT '分类ID',
  `authorid` mediumint(7) NOT NULL DEFAULT '0' COMMENT '审核者ID',
  `uid` mediumint(7) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `username` varchar(30) NOT NULL DEFAULT '' COMMENT '用户昵称',
  `update_time` int(10) NOT NULL DEFAULT '0' COMMENT '提交时间',
  `content` text NOT NULL COMMENT '评论内容',
  `ip` varchar(15) NOT NULL DEFAULT '' COMMENT '用户IP地址',
  `icon` tinyint(3) NOT NULL DEFAULT '0' COMMENT '表情',
  `yz` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否验证',
  `ifcom` tinyint(1) NOT NULL DEFAULT '0',
  `agree` mediumint(5) NOT NULL DEFAULT '0',
  `disagree` mediumint(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `aid` (`aid`),
  KEY `fid` (`cid`),
  KEY `uid` (`uid`),
  KEY `ifcom` (`ifcom`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `onethink_comment`
-- -----------------------------
INSERT INTO `onethink_comment` VALUES ('1', '604', '39', '1', '1', 'admin', '1289286091', '好东西大家要一起分离的哦', '127.0.0.1', '1', '1', '0', '0', '0');
INSERT INTO `onethink_comment` VALUES ('2', '566', '39', '1', '1', 'admin', '1289286118', '受教非浅.大家都要过来看看,不看会后悔的呀\\', '127.0.0.1', '1', '1', '0', '0', '0');
INSERT INTO `onethink_comment` VALUES ('3', '567', '39', '1', '1', 'admin', '1289286144', '想要在电子商务方面成功,实战很重要!', '127.0.0.1', '1', '1', '0', '0', '0');
INSERT INTO `onethink_comment` VALUES ('24', '1', '2', '0', '1', 'Administrator', '1419909163', 'sdfsdf', '127.0.0.1', '0', '1', '0', '0', '0');
INSERT INTO `onethink_comment` VALUES ('25', '1', '2', '0', '0', '', '1419909353', 'sdfsf', '127.0.0.1', '0', '1', '0', '0', '0');

-- -----------------------------
-- Table structure for `onethink_config`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_config`;
CREATE TABLE `onethink_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '配置ID',
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '配置名称',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置类型',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '配置说明',
  `group` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置分组',
  `extra` varchar(255) NOT NULL DEFAULT '' COMMENT '配置值',
  `remark` varchar(100) NOT NULL COMMENT '配置说明',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态',
  `value` text NOT NULL COMMENT '配置值',
  `sort` smallint(3) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`),
  KEY `type` (`type`),
  KEY `group` (`group`)
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `onethink_config`
-- -----------------------------
INSERT INTO `onethink_config` VALUES ('1', 'WEB_SITE_TITLE', '1', '网站标题', '1', '', '网站标题前台显示标题', '1378898976', '1379235274', '1', '露营游戏', '0');
INSERT INTO `onethink_config` VALUES ('2', 'WEB_SITE_DESCRIPTION', '2', '网站描述', '1', '', '网站搜索引擎描述', '1378898976', '1379235841', '1', '露营游戏', '1');
INSERT INTO `onethink_config` VALUES ('3', 'WEB_SITE_KEYWORD', '2', '网站关键字', '1', '', '网站搜索引擎关键字', '1378898976', '1381390100', '1', '露营，游戏', '8');
INSERT INTO `onethink_config` VALUES ('4', 'WEB_SITE_CLOSE', '4', '关闭站点', '1', '0:关闭,1:开启', '站点关闭后其他用户不能访问，管理员可以正常访问', '1378898976', '1379235296', '1', '1', '1');
INSERT INTO `onethink_config` VALUES ('9', 'CONFIG_TYPE_LIST', '3', '配置类型列表', '4', '', '主要用于数据解析和页面表单的生成', '1378898976', '1379235348', '1', '0:数字\r\n1:字符\r\n2:文本\r\n3:数组\r\n4:枚举', '2');
INSERT INTO `onethink_config` VALUES ('10', 'WEB_SITE_ICP', '1', '网站备案号', '1', '', '设置在网站底部显示的备案号，如“沪ICP备12007941号-2', '1378900335', '1379235859', '1', '', '9');
INSERT INTO `onethink_config` VALUES ('11', 'DOCUMENT_POSITION', '3', '文档推荐位', '2', '', '文档推荐位，推荐到多个位置KEY值相加即可', '1379053380', '1379235329', '1', '1:列表页推荐\r\n2:频道页推荐\r\n4:网站首页推荐', '3');
INSERT INTO `onethink_config` VALUES ('12', 'DOCUMENT_DISPLAY', '3', '文档可见性', '2', '', '文章可见性仅影响前台显示，后台不收影响', '1379056370', '1379235322', '1', '0:所有人可见\r\n1:仅注册会员可见\r\n2:仅管理员可见', '4');
INSERT INTO `onethink_config` VALUES ('13', 'COLOR_STYLE', '4', '后台色系', '1', 'default_color:默认\r\nblue_color:紫罗兰', '后台颜色风格', '1379122533', '1379235904', '1', 'default_color', '10');
INSERT INTO `onethink_config` VALUES ('20', 'CONFIG_GROUP_LIST', '3', '配置分组', '4', '', '配置分组', '1379228036', '1384418383', '1', '1:基本\r\n2:内容\r\n3:用户\r\n4:系统', '4');
INSERT INTO `onethink_config` VALUES ('21', 'HOOKS_TYPE', '3', '钩子的类型', '4', '', '类型 1-用于扩展显示内容，2-用于扩展业务处理', '1379313397', '1379313407', '1', '1:视图\r\n2:控制器', '6');
INSERT INTO `onethink_config` VALUES ('22', 'AUTH_CONFIG', '3', 'Auth配置', '4', '', '自定义Auth.class.php类配置', '1379409310', '1379409564', '1', 'AUTH_ON:1\r\nAUTH_TYPE:2', '8');
INSERT INTO `onethink_config` VALUES ('23', 'OPEN_DRAFTBOX', '4', '是否开启草稿功能', '2', '0:关闭草稿功能\r\n1:开启草稿功能\r\n', '新增文章时的草稿功能配置', '1379484332', '1379484591', '1', '1', '1');
INSERT INTO `onethink_config` VALUES ('24', 'DRAFT_AOTOSAVE_INTERVAL', '0', '自动保存草稿时间', '2', '', '自动保存草稿的时间间隔，单位：秒', '1379484574', '1386143323', '1', '60', '2');
INSERT INTO `onethink_config` VALUES ('25', 'LIST_ROWS', '0', '后台每页记录数', '2', '', '后台数据每页显示记录数', '1379503896', '1380427745', '1', '10', '10');
INSERT INTO `onethink_config` VALUES ('26', 'USER_ALLOW_REGISTER', '4', '是否允许用户注册', '3', '0:关闭注册\r\n1:允许注册', '是否开放用户注册', '1379504487', '1379504580', '1', '1', '3');
INSERT INTO `onethink_config` VALUES ('27', 'CODEMIRROR_THEME', '4', '预览插件的CodeMirror主题', '4', '3024-day:3024 day\r\n3024-night:3024 night\r\nambiance:ambiance\r\nbase16-dark:base16 dark\r\nbase16-light:base16 light\r\nblackboard:blackboard\r\ncobalt:cobalt\r\neclipse:eclipse\r\nelegant:elegant\r\nerlang-dark:erlang-dark\r\nlesser-dark:lesser-dark\r\nmidnight:midnight', '详情见CodeMirror官网', '1379814385', '1384740813', '1', 'ambiance', '3');
INSERT INTO `onethink_config` VALUES ('28', 'DATA_BACKUP_PATH', '1', '数据库备份根路径', '4', '', '路径必须以 / 结尾', '1381482411', '1381482411', '1', './Data/', '5');
INSERT INTO `onethink_config` VALUES ('29', 'DATA_BACKUP_PART_SIZE', '0', '数据库备份卷大小', '4', '', '该值用于限制压缩后的分卷最大长度。单位：B；建议设置20M', '1381482488', '1381729564', '1', '20971520', '7');
INSERT INTO `onethink_config` VALUES ('30', 'DATA_BACKUP_COMPRESS', '4', '数据库备份文件是否启用压缩', '4', '0:不压缩\r\n1:启用压缩', '压缩备份文件需要PHP环境支持gzopen,gzwrite函数', '1381713345', '1381729544', '1', '1', '9');
INSERT INTO `onethink_config` VALUES ('31', 'DATA_BACKUP_COMPRESS_LEVEL', '4', '数据库备份文件压缩级别', '4', '1:普通\r\n4:一般\r\n9:最高', '数据库备份文件的压缩级别，该配置在开启压缩时生效', '1381713408', '1381713408', '1', '9', '10');
INSERT INTO `onethink_config` VALUES ('32', 'DEVELOP_MODE', '4', '开启开发者模式', '4', '0:关闭\r\n1:开启', '是否开启开发者模式', '1383105995', '1383291877', '1', '1', '11');
INSERT INTO `onethink_config` VALUES ('33', 'ALLOW_VISIT', '3', '不受限控制器方法', '0', '', '', '1386644047', '1386644741', '1', '0:article/draftbox\r\n1:article/mydocument\r\n2:Category/tree\r\n3:Index/verify\r\n4:file/upload\r\n5:file/download\r\n6:user/updatePassword\r\n7:user/updateNickname\r\n8:user/submitPassword\r\n9:user/submitNickname\r\n10:file/uploadpicture', '0');
INSERT INTO `onethink_config` VALUES ('34', 'DENY_VISIT', '3', '超管专限控制器方法', '0', '', '仅超级管理员可访问的控制器方法', '1386644141', '1386644659', '1', '0:Addons/addhook\r\n1:Addons/edithook\r\n2:Addons/delhook\r\n3:Addons/updateHook\r\n4:Admin/getMenus\r\n5:Admin/recordList\r\n6:AuthManager/updateRules\r\n7:AuthManager/tree', '0');
INSERT INTO `onethink_config` VALUES ('35', 'REPLY_LIST_ROWS', '0', '回复列表每页条数', '2', '', '', '1386645376', '1387178083', '1', '10', '0');
INSERT INTO `onethink_config` VALUES ('36', 'ADMIN_ALLOW_IP', '2', '后台允许访问IP', '4', '', '多个用逗号分隔，如果不配置表示不限制IP访问', '1387165454', '1387165553', '1', '', '12');
INSERT INTO `onethink_config` VALUES ('37', 'SHOW_PAGE_TRACE', '4', '是否显示页面Trace', '4', '0:关闭\r\n1:开启', '是否显示页面Trace信息', '1387165685', '1387165685', '1', '0', '1');

-- -----------------------------
-- Table structure for `onethink_document`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_document`;
CREATE TABLE `onethink_document` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `name` char(40) NOT NULL COMMENT '标识',
  `title` char(80) NOT NULL COMMENT '标题',
  `category_id` int(10) unsigned NOT NULL COMMENT '所属分类',
  `description` char(140) NOT NULL DEFAULT '' COMMENT '描述',
  `root` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '根节点',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '所属ID',
  `model_id` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '内容模型ID',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '2' COMMENT '内容类型',
  `position` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '推荐位',
  `link_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '外链',
  `cover_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '封面',
  `display` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '可见性',
  `deadline` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '截至时间',
  `attach` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '附件数量',
  `view` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '浏览量',
  `comment` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '评论数',
  `extend` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '扩展统计字段',
  `level` int(10) NOT NULL DEFAULT '0' COMMENT '优先级',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '数据状态',
  PRIMARY KEY (`id`),
  KEY `idx_category_status` (`category_id`,`status`),
  KEY `idx_status_type_pid` (`status`,`uid`,`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='文档模型基础表';

-- -----------------------------
-- Records of `onethink_document`
-- -----------------------------
INSERT INTO `onethink_document` VALUES ('1', '1', '', 'OneThink1.0正式版发布', '2', '大家期待的OneThink正式版发布', '0', '0', '2', '2', '0', '0', '0', '1', '0', '0', '9', '0', '0', '0', '1387260660', '1387263112', '1');

-- -----------------------------
-- Table structure for `onethink_document2`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_document2`;
CREATE TABLE `onethink_document2` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `bivName` text NOT NULL COMMENT '营地名称',
  `content` text NOT NULL COMMENT '营地信息详情',
  `bivAdd` text NOT NULL COMMENT '营地具体地址',
  `bivFood` text NOT NULL COMMENT '美食介绍',
  `bivHouse` text NOT NULL COMMENT '住宿描述',
  `bivType` char(50) NOT NULL COMMENT '营地类型',
  `campType` char(50) NOT NULL DEFAULT '作为露营方式的搜索标签' COMMENT '露营类型',
  `bivImg` varchar(255) NOT NULL DEFAULT '展示于首页的图片' COMMENT '首页图片',
  `gamesBg` text NOT NULL COMMENT '游戏设置背景',
  `gameDes` text NOT NULL COMMENT '游戏规则描述',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;


-- -----------------------------
-- Table structure for `onethink_document_article`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_document_article`;
CREATE TABLE `onethink_document_article` (
  `id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文档ID',
  `parse` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '内容解析类型',
  `content` text NOT NULL COMMENT '文章内容',
  `template` varchar(100) NOT NULL COMMENT '详情页显示模板',
  `bookmark` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '收藏数',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文档模型文章表';

-- -----------------------------
-- Records of `onethink_document_article`
-- -----------------------------
INSERT INTO `onethink_document_article` VALUES ('1', '0', '<h1>\r\n	OneThink1.0正式版发布&nbsp;\r\n</h1>\r\n<p>\r\n	<br />\r\n</p>\r\n<p>\r\n	<strong>OneThink是一个开源的内容管理框架，基于最新的ThinkPHP3.2版本开发，提供更方便、更安全的WEB应用开发体验，采用了全新的架构设计和命名空间机制，融合了模块化、驱动化和插件化的设计理念于一体，开启了国内WEB应用傻瓜式开发的新潮流。&nbsp;</strong> \r\n</p>\r\n<h2>\r\n	主要特性：\r\n</h2>\r\n<p>\r\n	1. 基于ThinkPHP最新3.2版本。\r\n</p>\r\n<p>\r\n	2. 模块化：全新的架构和模块化的开发机制，便于灵活扩展和二次开发。&nbsp;\r\n</p>\r\n<p>\r\n	3. 文档模型/分类体系：通过和文档模型绑定，以及不同的文档类型，不同分类可以实现差异化的功能，轻松实现诸如资讯、下载、讨论和图片等功能。\r\n</p>\r\n<p>\r\n	4. 开源免费：OneThink遵循Apache2开源协议,免费提供使用。&nbsp;\r\n</p>\r\n<p>\r\n	5. 用户行为：支持自定义用户行为，可以对单个用户或者群体用户的行为进行记录及分享，为您的运营决策提供有效参考数据。\r\n</p>\r\n<p>\r\n	6. 云端部署：通过驱动的方式可以轻松支持平台的部署，让您的网站无缝迁移，内置已经支持SAE和BAE3.0。\r\n</p>\r\n<p>\r\n	7. 云服务支持：即将启动支持云存储、云安全、云过滤和云统计等服务，更多贴心的服务让您的网站更安心。\r\n</p>\r\n<p>\r\n	8. 安全稳健：提供稳健的安全策略，包括备份恢复、容错、防止恶意攻击登录，网页防篡改等多项安全管理功能，保证系统安全，可靠、稳定的运行。&nbsp;\r\n</p>\r\n<p>\r\n	9. 应用仓库：官方应用仓库拥有大量来自第三方插件和应用模块、模板主题，有众多来自开源社区的贡献，让您的网站“One”美无缺。&nbsp;\r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<p>\r\n	<strong>&nbsp;OneThink集成了一个完善的后台管理体系和前台模板标签系统，让你轻松管理数据和进行前台网站的标签式开发。&nbsp;</strong> \r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<h2>\r\n	后台主要功能：\r\n</h2>\r\n<p>\r\n	1. 用户Passport系统\r\n</p>\r\n<p>\r\n	2. 配置管理系统&nbsp;\r\n</p>\r\n<p>\r\n	3. 权限控制系统\r\n</p>\r\n<p>\r\n	4. 后台建模系统&nbsp;\r\n</p>\r\n<p>\r\n	5. 多级分类系统&nbsp;\r\n</p>\r\n<p>\r\n	6. 用户行为系统&nbsp;\r\n</p>\r\n<p>\r\n	7. 钩子和插件系统\r\n</p>\r\n<p>\r\n	8. 系统日志系统&nbsp;\r\n</p>\r\n<p>\r\n	9. 数据备份和还原\r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<p>\r\n	&nbsp;[ 官方下载：&nbsp;<a href=\"http://www.onethink.cn/download.html\" target=\"_blank\">http://www.onethink.cn/download.html</a>&nbsp;&nbsp;开发手册：<a href=\"http://document.onethink.cn/\" target=\"_blank\">http://document.onethink.cn/</a>&nbsp;]&nbsp;\r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<p>\r\n	<strong>OneThink开发团队 2013</strong> \r\n</p>', '', '0');

-- -----------------------------
-- Table structure for `onethink_document_download`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_document_download`;
CREATE TABLE `onethink_document_download` (
  `id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文档ID',
  `parse` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '内容解析类型',
  `content` text NOT NULL COMMENT '下载详细描述',
  `template` varchar(100) NOT NULL DEFAULT '' COMMENT '详情页显示模板',
  `file_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文件ID',
  `download` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '下载次数',
  `size` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文档模型下载表';


-- -----------------------------
-- Table structure for `onethink_document_luying`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_document_luying`;
CREATE TABLE `onethink_document_luying` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `bivAdd` varchar(255) NOT NULL COMMENT '营地具体地址',
  `bivName` varchar(255) NOT NULL COMMENT '营地名称',
  `bivImg` int(10) unsigned NOT NULL COMMENT '首页图片',
  `bivImgs` varchar(255) NOT NULL COMMENT '营地图片展示',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;


-- -----------------------------
-- Table structure for `onethink_file`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_file`;
CREATE TABLE `onethink_file` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文件ID',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '原始文件名',
  `savename` char(20) NOT NULL DEFAULT '' COMMENT '保存名称',
  `savepath` char(30) NOT NULL DEFAULT '' COMMENT '文件保存路径',
  `ext` char(5) NOT NULL DEFAULT '' COMMENT '文件后缀',
  `mime` char(40) NOT NULL DEFAULT '' COMMENT '文件mime类型',
  `size` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  `md5` char(32) NOT NULL DEFAULT '' COMMENT '文件md5',
  `sha1` char(40) NOT NULL DEFAULT '' COMMENT '文件 sha1编码',
  `location` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '文件保存位置',
  `create_time` int(10) unsigned NOT NULL COMMENT '上传时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_md5` (`md5`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文件表';


-- -----------------------------
-- Table structure for `onethink_friendlink`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_friendlink`;
CREATE TABLE `onethink_friendlink` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `title` varchar(255) NOT NULL COMMENT '站点名称',
  `url` varchar(255) NOT NULL COMMENT '链接地址',
  `status` char(50) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- -----------------------------
-- Records of `onethink_friendlink`
-- -----------------------------
INSERT INTO `onethink_friendlink` VALUES ('1', 'Onethink', 'http://www.onethink.com', '0');
INSERT INTO `onethink_friendlink` VALUES ('2', 'jobdeer', 'http://www.jobdeer.com', '0');

-- -----------------------------
-- Table structure for `onethink_frienlink`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_frienlink`;
CREATE TABLE `onethink_frienlink` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `URL` varchar(255) NOT NULL COMMENT '站点1',
  `status` char(50) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;


-- -----------------------------
-- Table structure for `onethink_hooks`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_hooks`;
CREATE TABLE `onethink_hooks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(40) NOT NULL DEFAULT '' COMMENT '钩子名称',
  `description` text NOT NULL COMMENT '描述',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '类型',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `addons` varchar(255) NOT NULL DEFAULT '' COMMENT '钩子挂载的插件 ''，''分割',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `onethink_hooks`
-- -----------------------------
INSERT INTO `onethink_hooks` VALUES ('1', 'pageHeader', '页面header钩子，一般用于加载插件CSS文件和代码', '1', '0', '');
INSERT INTO `onethink_hooks` VALUES ('2', 'pageFooter', '页面footer钩子，一般用于加载插件JS文件和JS代码', '1', '0', 'ReturnTop');
INSERT INTO `onethink_hooks` VALUES ('3', 'documentEditForm', '添加编辑表单的 扩展内容钩子', '1', '0', 'Attachment');
INSERT INTO `onethink_hooks` VALUES ('4', 'documentDetailAfter', '文档末尾显示', '1', '0', 'Attachment,SocialComment');
INSERT INTO `onethink_hooks` VALUES ('5', 'documentDetailBefore', '页面内容前显示用钩子', '1', '0', '');
INSERT INTO `onethink_hooks` VALUES ('6', 'documentSaveComplete', '保存文档数据后的扩展钩子', '2', '0', 'Attachment');
INSERT INTO `onethink_hooks` VALUES ('7', 'documentEditFormContent', '添加编辑表单的内容显示钩子', '1', '0', 'Editor');
INSERT INTO `onethink_hooks` VALUES ('8', 'adminArticleEdit', '后台内容编辑页编辑器', '1', '1378982734', 'EditorForAdmin');
INSERT INTO `onethink_hooks` VALUES ('13', 'AdminIndex', '首页小格子个性化显示', '1', '1382596073', 'SiteStat,SystemInfo,DevTeam');
INSERT INTO `onethink_hooks` VALUES ('14', 'topicComment', '评论提交方式扩展钩子。', '1', '1380163518', 'Editor');
INSERT INTO `onethink_hooks` VALUES ('16', 'app_begin', '应用开始', '2', '1384481614', '');

-- -----------------------------
-- Table structure for `onethink_ladmin`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_ladmin`;
CREATE TABLE `onethink_ladmin` (
  `aID` int(11) NOT NULL COMMENT 'ID号',
  `adminName` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT '登录名',
  `adminPwd` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT '管理员密码',
  `adminTel` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT '电话',
  `realName` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT '管理员姓名',
  `addTime` date NOT NULL COMMENT '注册日期',
  `adminEmail` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT '邮箱',
  PRIMARY KEY (`aID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- -----------------------------
-- Records of `onethink_ladmin`
-- -----------------------------
INSERT INTO `onethink_ladmin` VALUES ('1308', 'admin', 'admin', '888888', 'admin', '2015-11-24', '1308@163.com');

-- -----------------------------
-- Table structure for `onethink_lagent`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_lagent`;
CREATE TABLE `onethink_lagent` (
  `agentID` int(10) NOT NULL AUTO_INCREMENT COMMENT '代理人编号',
  `agentName` varchar(100) CHARACTER SET utf8 DEFAULT NULL COMMENT '代理人昵称',
  `realName` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '真实姓名',
  `cardNumber` varchar(30) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '身份证号码',
  `agentAddress` varchar(30) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '家庭住址',
  `status` int(11) DEFAULT NULL,
  `agentTel` int(50) DEFAULT NULL COMMENT '代理人联系方式',
  `agentEmail` int(50) DEFAULT NULL COMMENT '代理人邮箱',
  `addTime` date DEFAULT NULL COMMENT '注册时间',
  PRIMARY KEY (`agentID`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

-- -----------------------------
-- Records of `onethink_lagent`
-- -----------------------------
INSERT INTO `onethink_lagent` VALUES ('1', 'admin', '', '123456', '浙江杭州', '', '123456', '', '');
INSERT INTO `onethink_lagent` VALUES ('7', 'agent1', '小琳', '2', '湖州', '0', '123456', '0', '2016-02-24');
INSERT INTO `onethink_lagent` VALUES ('9', 'agent2', '小徐', '1', '湖州', '1', '123456', '0', '2016-02-24');

-- -----------------------------
-- Table structure for `onethink_lbivouac`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_lbivouac`;
CREATE TABLE `onethink_lbivouac` (
  `bivouacID` int(11) NOT NULL AUTO_INCREMENT COMMENT '露营地编号',
  `numX` float(30,0) DEFAULT NULL COMMENT 'x坐标',
  `numY` float(30,0) DEFAULT NULL COMMENT 'y坐标',
  `bivAdd` varchar(30) CHARACTER SET utf8 DEFAULT NULL COMMENT '地址',
  `agentID` int(10) DEFAULT NULL COMMENT '代理人编号',
  `bivName` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '露营地名称',
  `bivGrade` int(11) DEFAULT NULL COMMENT '露营地等级',
  `bivImg` varchar(100) CHARACTER SET utf8 DEFAULT NULL COMMENT '营地图片',
  `bivDes` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '营地简介',
  `bivHouse` varchar(100) CHARACTER SET utf8 DEFAULT NULL COMMENT '住宿描述',
  `bivFood` varchar(100) CHARACTER SET utf8 DEFAULT NULL COMMENT '美食描述',
  `bivWea` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '天气',
  `bivType` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '露营地类型',
  `Status` int(10) DEFAULT '0' COMMENT '营地信息审核通过状态',
  `bivVisit` int(255) DEFAULT '0' COMMENT '营地访问量',
  `bivEva` int(255) DEFAULT '0' COMMENT '营地总评',
  `model_id` tinyint(3) unsigned DEFAULT '0' COMMENT '内容模型ID',
  `category_id` int(10) DEFAULT NULL COMMENT '所属类型',
  `campType` varchar(10) CHARACTER SET utf8 DEFAULT NULL COMMENT '露营方式',
  `campCol` int(10) DEFAULT NULL,
  `content` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '营地详细介绍',
  PRIMARY KEY (`bivouacID`),
  KEY `ID` (`agentID`),
  CONSTRAINT `ID` FOREIGN KEY (`agentID`) REFERENCES `onethink_lagent` (`agentID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- -----------------------------
-- Records of `onethink_lbivouac`
-- -----------------------------
INSERT INTO `onethink_lbivouac` VALUES ('1', '2', '2', '浙江杭州', '7', '大清谷', '2', '2', 'great', '很舒服', '美味', '2', '湖畔型', '2', '2', '2', '2', '2', '帐篷', '0', '特色');
INSERT INTO `onethink_lbivouac` VALUES ('2', '1', '1', '浙江杭州', '9', '桐庐', '1', '1', '爱心真潇洒走潇洒差多少出<img src=\"/onethink1/Uploads/Editor/2016-02-24/56cd546b45548.jpg\" alt=\"\" /><br />', '很舒服', '美味', '1', '草丛型', '1', '1', '1', '2', '2', '树屋', '0', '优雅阿萨德撒的记叙文新街口离散战斗机及案例卡记录是哪句真就偶是你打拉大锯是');

-- -----------------------------
-- Table structure for `onethink_lcamp`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_lcamp`;
CREATE TABLE `onethink_lcamp` (
  `campID` int(11) NOT NULL AUTO_INCREMENT COMMENT '活动编号',
  `campName` varchar(11) CHARACTER SET utf8 DEFAULT NULL COMMENT '活动名称',
  `agentID` int(255) DEFAULT NULL COMMENT '代理人编号',
  `bivouacID` int(255) DEFAULT NULL COMMENT '露营地编号',
  `campAmount` int(11) DEFAULT NULL COMMENT '预定人数',
  `campPrice` int(11) DEFAULT NULL COMMENT '单人单个活动价格',
  `startTime` time DEFAULT NULL COMMENT '开始时间',
  `endTime` time DEFAULT NULL COMMENT '结束时间',
  `campRisk` int(11) DEFAULT NULL COMMENT '冒险度',
  `campHot` float(11,0) DEFAULT NULL COMMENT '欢迎度',
  `campSafety` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '安全须知',
  `gamesBg` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '整个活动背景',
  `Status` int(10) DEFAULT '0' COMMENT '状态',
  `count` int(20) DEFAULT NULL COMMENT '所含游戏数',
  PRIMARY KEY (`campID`),
  KEY `ID2` (`bivouacID`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

-- -----------------------------
-- Records of `onethink_lcamp`
-- -----------------------------
INSERT INTO `onethink_lcamp` VALUES ('11', '魔法传说', '7', '1', '8', '100', '09:00:00', '10:00:00', '', '9', '11', '', '', '');
INSERT INTO `onethink_lcamp` VALUES ('13', '活动1', '0', '0', '8', '100', '09:00:00', '10:00:00', '', '', '123', '', '', '');

-- -----------------------------
-- Table structure for `onethink_lgame`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_lgame`;
CREATE TABLE `onethink_lgame` (
  `gameID` int(11) NOT NULL AUTO_INCREMENT COMMENT '游戏编号',
  `gameName` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT '游戏名',
  `campID` int(11) NOT NULL COMMENT '活动编号',
  `gameRisk` int(11) NOT NULL COMMENT '游戏难度',
  `gameHot` int(11) DEFAULT NULL COMMENT '游戏欢迎度',
  `gameBrains` int(11) DEFAULT NULL COMMENT '智力值',
  `gamePower` int(11) NOT NULL COMMENT '体力值',
  `gameExp` int(11) DEFAULT NULL COMMENT '经验值',
  `gameGrade` int(11) DEFAULT NULL COMMENT '等级值',
  `gameCoop` int(11) DEFAULT NULL COMMENT '合作值',
  `gameBlood` int(11) NOT NULL COMMENT '血量',
  `gameGold` int(11) DEFAULT NULL COMMENT '金币',
  `gameRole` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '游戏角色',
  `gameDes` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT '游戏规则描述',
  `gameType` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT '游戏类型',
  `Status` varchar(10) CHARACTER SET utf8 NOT NULL COMMENT '状态',
  PRIMARY KEY (`gameID`),
  KEY `ID3` (`campID`),
  CONSTRAINT `ID3` FOREIGN KEY (`campID`) REFERENCES `onethink_lcamp` (`campID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


-- -----------------------------
-- Table structure for `onethink_lgtype`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_lgtype`;
CREATE TABLE `onethink_lgtype` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `gameType` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT '游戏类型',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

-- -----------------------------
-- Records of `onethink_lgtype`
-- -----------------------------
INSERT INTO `onethink_lgtype` VALUES ('1', '益智类');
INSERT INTO `onethink_lgtype` VALUES ('2', '策略类');
INSERT INTO `onethink_lgtype` VALUES ('3', '冒险类');
INSERT INTO `onethink_lgtype` VALUES ('4', '射击类');
INSERT INTO `onethink_lgtype` VALUES ('5', '动作类');
INSERT INTO `onethink_lgtype` VALUES ('6', '体育类');

-- -----------------------------
-- Table structure for `onethink_lodetail`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_lodetail`;
CREATE TABLE `onethink_lodetail` (
  `ID` int(255) NOT NULL AUTO_INCREMENT COMMENT '序号',
  `orderID` int(10) DEFAULT NULL COMMENT '订单编号',
  `userID` int(10) DEFAULT NULL COMMENT '消费者ID',
  `campCom` int(255) DEFAULT NULL COMMENT '活动评价',
  `presetTime` datetime DEFAULT NULL COMMENT '下单时间',
  `bivouacID` int(11) DEFAULT NULL COMMENT '营地ID',
  `campStime` date DEFAULT NULL COMMENT '露营开始时间',
  `campEtime` date DEFAULT NULL COMMENT '露营结束时间',
  `gameStime` datetime DEFAULT NULL COMMENT '游戏开始时间',
  `gameEtime` datetime DEFAULT NULL COMMENT '游戏结束时间',
  `teamName` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '游戏队伍名',
  `Status` int(255) DEFAULT NULL COMMENT '订单状态',
  `campPrice` int(255) DEFAULT NULL COMMENT '单人单次价格',
  PRIMARY KEY (`ID`),
  KEY `id2` (`userID`) USING BTREE,
  KEY `id1` (`orderID`) USING BTREE,
  KEY `id3` (`bivouacID`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- -----------------------------
-- Records of `onethink_lodetail`
-- -----------------------------
INSERT INTO `onethink_lodetail` VALUES ('1', '1', '4', '', '2016-03-04 21:04:53', '1', '2016-03-05', '2016-03-06', '2016-03-05 09:00:00', '2016-03-06 10:00:00', '队名1', '0', '100');
INSERT INTO `onethink_lodetail` VALUES ('2', '1', '5', '', '2016-03-04 21:06:30', '1', '2016-03-05', '2016-03-06', '2016-03-05 09:00:00', '2016-03-06 10:00:00', '队名1', '0', '100');
INSERT INTO `onethink_lodetail` VALUES ('3', '1', '6', '', '2016-03-04 21:07:35', '1', '2016-03-05', '2016-03-06', '2016-03-05 09:00:00', '2016-03-06 10:00:00', '队名1', '0', '100');
INSERT INTO `onethink_lodetail` VALUES ('4', '1', '3', '', '2016-03-04 19:23:21', '1', '2016-03-05', '2016-03-06', '2016-03-05 09:00:00', '2016-03-10 10:00:00', '队名1', '0', '100');

-- -----------------------------
-- Table structure for `onethink_lorder`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_lorder`;
CREATE TABLE `onethink_lorder` (
  `orderID` int(10) NOT NULL COMMENT '订单号',
  `bivouacID` int(11) NOT NULL COMMENT '露营地编号',
  `teamName` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT '游戏队伍名',
  `sum` int(255) NOT NULL COMMENT '总人数',
  `count` int(255) NOT NULL COMMENT '规定人数',
  PRIMARY KEY (`orderID`),
  KEY `ID5` (`bivouacID`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- -----------------------------
-- Records of `onethink_lorder`
-- -----------------------------
INSERT INTO `onethink_lorder` VALUES ('1', '1', '1', '8', '8');

-- -----------------------------
-- Table structure for `onethink_lstore`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_lstore`;
CREATE TABLE `onethink_lstore` (
  `goodsID` int(11) NOT NULL COMMENT '商品编号',
  `goodsName` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT '商品名',
  `gameID` int(11) NOT NULL COMMENT '游戏编号',
  `blood` int(11) NOT NULL COMMENT '血量',
  `power` int(11) NOT NULL COMMENT '体力值',
  `brains` int(11) NOT NULL COMMENT '智力值',
  `price` int(11) NOT NULL COMMENT '价格',
  `describe` varchar(255) CHARACTER SET utf8 NOT NULL COMMENT '描述',
  PRIMARY KEY (`goodsID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


-- -----------------------------
-- Table structure for `onethink_luser`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_luser`;
CREATE TABLE `onethink_luser` (
  `userID` int(255) NOT NULL COMMENT '消费者ID',
  `userName` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '消费者用户名',
  `userPwd` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '密码',
  `userTel` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '手机号',
  `userSex` varchar(11) CHARACTER SET utf8 DEFAULT NULL COMMENT '性别',
  `userAdd` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '所在地',
  `userFace` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '头像',
  `userRName` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '真实姓名',
  `addTime` date DEFAULT NULL,
  `userPower` int(11) DEFAULT NULL COMMENT '体力值',
  `userBrains` int(11) DEFAULT NULL COMMENT '智力值',
  `userExp` int(11) DEFAULT NULL COMMENT '经验值',
  `userGrade` int(255) DEFAULT NULL COMMENT '等级值',
  `userCooperate` int(11) DEFAULT NULL COMMENT '合作值',
  `userGold` int(11) DEFAULT NULL COMMENT '金币',
  `userBlood` int(11) DEFAULT NULL COMMENT '血量',
  PRIMARY KEY (`userID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- -----------------------------
-- Records of `onethink_luser`
-- -----------------------------
INSERT INTO `onethink_luser` VALUES ('1', 'guest2', 'guest2', '123456', '男', '浙江杭州', '', '小佳', '2015-12-03', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `onethink_luser` VALUES ('2', 'guest3', 'guest3', '123456', '女', '浙江杭州', '', '小琳', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `onethink_luying`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_luying`;
CREATE TABLE `onethink_luying` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `campSafety` text NOT NULL COMMENT '安全须知',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;


-- -----------------------------
-- Table structure for `onethink_lwish`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_lwish`;
CREATE TABLE `onethink_lwish` (
  `wishID` int(11) NOT NULL COMMENT '愿望编号',
  `userID` int(11) NOT NULL COMMENT '消费者编号',
  `wishDes` varchar(255) NOT NULL COMMENT '愿望描述',
  PRIMARY KEY (`wishID`),
  KEY `ID6` (`userID`),
  CONSTRAINT `ID6` FOREIGN KEY (`userID`) REFERENCES `onethink_luser` (`userID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


-- -----------------------------
-- Table structure for `onethink_member`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_member`;
CREATE TABLE `onethink_member` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `nickname` char(16) NOT NULL DEFAULT '' COMMENT '昵称',
  `sex` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '性别',
  `birthday` date NOT NULL DEFAULT '0000-00-00' COMMENT '生日',
  `qq` char(10) NOT NULL DEFAULT '' COMMENT 'qq号',
  `score` mediumint(8) NOT NULL DEFAULT '0' COMMENT '用户积分',
  `login` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '登录次数',
  `reg_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '注册IP',
  `reg_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '注册时间',
  `last_login_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '最后登录IP',
  `last_login_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后登录时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '会员状态',
  PRIMARY KEY (`uid`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COMMENT='会员表';

-- -----------------------------
-- Records of `onethink_member`
-- -----------------------------
INSERT INTO `onethink_member` VALUES ('1', 'admin', '0', '0000-00-00', '', '270', '46', '0', '1447931494', '2130706433', '1459774930', '1');
INSERT INTO `onethink_member` VALUES ('2', 'admin1', '0', '0000-00-00', '', '0', '0', '0', '0', '0', '0', '1');
INSERT INTO `onethink_member` VALUES ('3', 'guest', '0', '0000-00-00', '', '30', '9', '2130706433', '1449750802', '2130706433', '1450091578', '1');
INSERT INTO `onethink_member` VALUES ('4', 'guest1', '0', '0000-00-00', '', '40', '9', '2130706433', '1450094045', '2130706433', '1457520312', '1');
INSERT INTO `onethink_member` VALUES ('5', 'guest2', '0', '0000-00-00', '', '10', '3', '2130706433', '1457093714', '2130706433', '1457094008', '1');
INSERT INTO `onethink_member` VALUES ('6', 'guest3', '0', '0000-00-00', '', '10', '1', '2130706433', '1457093821', '2130706433', '1457093821', '1');
INSERT INTO `onethink_member` VALUES ('7', 'agent1', '0', '0000-00-00', '', '10', '1', '0', '0', '2130706433', '1457607263', '1');
INSERT INTO `onethink_member` VALUES ('8', 'agent2', '0', '0000-00-00', '', '0', '0', '0', '0', '0', '0', '-1');
INSERT INTO `onethink_member` VALUES ('9', 'agent2', '0', '0000-00-00', '', '10', '1', '2130706433', '1457695932', '2130706433', '1457695932', '1');

-- -----------------------------
-- Table structure for `onethink_menu`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_menu`;
CREATE TABLE `onethink_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '标题',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序（同级有效）',
  `url` char(255) NOT NULL DEFAULT '' COMMENT '链接地址',
  `hide` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否隐藏',
  `tip` varchar(255) NOT NULL DEFAULT '' COMMENT '提示',
  `group` varchar(50) DEFAULT '' COMMENT '分组',
  `is_dev` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否仅开发者模式可见',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=171 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `onethink_menu`
-- -----------------------------
INSERT INTO `onethink_menu` VALUES ('1', '首页', '0', '1', 'Index/index', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('2', '内容', '0', '2', 'Article/mydocument', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('3', '文档列表', '2', '0', 'article/index', '1', '', '内容', '0');
INSERT INTO `onethink_menu` VALUES ('4', '新增', '3', '0', 'article/add', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('5', '编辑', '3', '0', 'article/edit', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('6', '改变状态', '3', '0', 'article/setStatus', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('7', '保存', '3', '0', 'article/update', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('8', '保存草稿', '3', '0', 'article/autoSave', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('9', '移动', '3', '0', 'article/move', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('10', '复制', '3', '0', 'article/copy', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('11', '粘贴', '3', '0', 'article/paste', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('12', '导入', '3', '0', 'article/batchOperate', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('13', '回收站', '2', '0', 'article/recycle', '1', '', '内容', '0');
INSERT INTO `onethink_menu` VALUES ('14', '还原', '13', '0', 'article/permit', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('15', '清空', '13', '0', 'article/clear', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('16', '管理中心', '0', '3', 'User/index', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('17', '用户信息', '16', '0', 'User/index', '0', '', '用户管理', '0');
INSERT INTO `onethink_menu` VALUES ('18', '新增用户', '17', '0', 'User/add', '0', '添加新用户', '', '0');
INSERT INTO `onethink_menu` VALUES ('19', '用户行为', '16', '0', 'User/action', '0', '', '行为管理', '0');
INSERT INTO `onethink_menu` VALUES ('20', '新增用户行为', '19', '0', 'User/addaction', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('21', '编辑用户行为', '19', '0', 'User/editaction', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('22', '保存用户行为', '19', '0', 'User/saveAction', '0', '\"用户->用户行为\"保存编辑和新增的用户行为', '', '0');
INSERT INTO `onethink_menu` VALUES ('23', '变更行为状态', '19', '0', 'User/setStatus', '0', '\"用户->用户行为\"中的启用,禁用和删除权限', '', '0');
INSERT INTO `onethink_menu` VALUES ('24', '禁用会员', '19', '0', 'User/changeStatus?method=forbidUser', '0', '\"用户->用户信息\"中的禁用', '', '0');
INSERT INTO `onethink_menu` VALUES ('25', '启用会员', '19', '0', 'User/changeStatus?method=resumeUser', '0', '\"用户->用户信息\"中的启用', '', '0');
INSERT INTO `onethink_menu` VALUES ('26', '删除会员', '19', '0', 'User/changeStatus?method=deleteUser', '0', '\"用户->用户信息\"中的删除', '', '0');
INSERT INTO `onethink_menu` VALUES ('27', '权限管理', '16', '0', 'AuthManager/index', '0', '', '用户管理', '0');
INSERT INTO `onethink_menu` VALUES ('28', '删除', '27', '0', 'AuthManager/changeStatus?method=deleteGroup', '0', '删除用户组', '', '0');
INSERT INTO `onethink_menu` VALUES ('29', '禁用', '27', '0', 'AuthManager/changeStatus?method=forbidGroup', '0', '禁用用户组', '', '0');
INSERT INTO `onethink_menu` VALUES ('30', '恢复', '27', '0', 'AuthManager/changeStatus?method=resumeGroup', '0', '恢复已禁用的用户组', '', '0');
INSERT INTO `onethink_menu` VALUES ('31', '新增', '27', '0', 'AuthManager/createGroup', '0', '创建新的用户组', '', '0');
INSERT INTO `onethink_menu` VALUES ('32', '编辑', '27', '0', 'AuthManager/editGroup', '0', '编辑用户组名称和描述', '', '0');
INSERT INTO `onethink_menu` VALUES ('33', '保存用户组', '27', '0', 'AuthManager/writeGroup', '0', '新增和编辑用户组的\"保存\"按钮', '', '0');
INSERT INTO `onethink_menu` VALUES ('34', '授权', '27', '0', 'AuthManager/group', '0', '\"后台 \\ 用户 \\ 用户信息\"列表页的\"授权\"操作按钮,用于设置用户所属用户组', '', '0');
INSERT INTO `onethink_menu` VALUES ('35', '访问授权', '27', '0', 'AuthManager/access', '0', '\"后台 \\ 用户 \\ 权限管理\"列表页的\"访问授权\"操作按钮', '', '0');
INSERT INTO `onethink_menu` VALUES ('36', '成员授权', '27', '0', 'AuthManager/user', '0', '\"后台 \\ 用户 \\ 权限管理\"列表页的\"成员授权\"操作按钮', '', '0');
INSERT INTO `onethink_menu` VALUES ('37', '解除授权', '27', '0', 'AuthManager/removeFromGroup', '0', '\"成员授权\"列表页内的解除授权操作按钮', '', '0');
INSERT INTO `onethink_menu` VALUES ('38', '保存成员授权', '27', '0', 'AuthManager/addToGroup', '0', '\"用户信息\"列表页\"授权\"时的\"保存\"按钮和\"成员授权\"里右上角的\"添加\"按钮)', '', '0');
INSERT INTO `onethink_menu` VALUES ('39', '分类授权', '27', '0', 'AuthManager/category', '0', '\"后台 \\ 用户 \\ 权限管理\"列表页的\"分类授权\"操作按钮', '', '0');
INSERT INTO `onethink_menu` VALUES ('40', '保存分类授权', '27', '0', 'AuthManager/addToCategory', '0', '\"分类授权\"页面的\"保存\"按钮', '', '0');
INSERT INTO `onethink_menu` VALUES ('41', '模型授权', '27', '0', 'AuthManager/modelauth', '0', '\"后台 \\ 用户 \\ 权限管理\"列表页的\"模型授权\"操作按钮', '', '0');
INSERT INTO `onethink_menu` VALUES ('42', '保存模型授权', '27', '0', 'AuthManager/addToModel', '0', '\"分类授权\"页面的\"保存\"按钮', '', '0');
INSERT INTO `onethink_menu` VALUES ('43', '扩展', '0', '7', 'Addons/index', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('44', '插件管理', '43', '1', 'Addons/index', '0', '', '扩展', '0');
INSERT INTO `onethink_menu` VALUES ('45', '创建', '44', '0', 'Addons/create', '0', '服务器上创建插件结构向导', '', '0');
INSERT INTO `onethink_menu` VALUES ('46', '检测创建', '44', '0', 'Addons/checkForm', '0', '检测插件是否可以创建', '', '0');
INSERT INTO `onethink_menu` VALUES ('47', '预览', '44', '0', 'Addons/preview', '0', '预览插件定义类文件', '', '0');
INSERT INTO `onethink_menu` VALUES ('48', '快速生成插件', '44', '0', 'Addons/build', '0', '开始生成插件结构', '', '0');
INSERT INTO `onethink_menu` VALUES ('49', '设置', '44', '0', 'Addons/config', '0', '设置插件配置', '', '0');
INSERT INTO `onethink_menu` VALUES ('50', '禁用', '44', '0', 'Addons/disable', '0', '禁用插件', '', '0');
INSERT INTO `onethink_menu` VALUES ('51', '启用', '44', '0', 'Addons/enable', '0', '启用插件', '', '0');
INSERT INTO `onethink_menu` VALUES ('52', '安装', '44', '0', 'Addons/install', '0', '安装插件', '', '0');
INSERT INTO `onethink_menu` VALUES ('53', '卸载', '44', '0', 'Addons/uninstall', '0', '卸载插件', '', '0');
INSERT INTO `onethink_menu` VALUES ('54', '更新配置', '44', '0', 'Addons/saveconfig', '0', '更新插件配置处理', '', '0');
INSERT INTO `onethink_menu` VALUES ('55', '插件后台列表', '44', '0', 'Addons/adminList', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('56', 'URL方式访问插件', '44', '0', 'Addons/execute', '0', '控制是否有权限通过url访问插件控制器方法', '', '0');
INSERT INTO `onethink_menu` VALUES ('57', '钩子管理', '43', '2', 'Addons/hooks', '0', '', '扩展', '0');
INSERT INTO `onethink_menu` VALUES ('58', '模型管理', '68', '3', 'Model/index', '0', '', '系统设置', '0');
INSERT INTO `onethink_menu` VALUES ('59', '新增', '58', '0', 'model/add', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('60', '编辑', '58', '0', 'model/edit', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('61', '改变状态', '58', '0', 'model/setStatus', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('62', '保存数据', '58', '0', 'model/update', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('63', '属性管理', '68', '0', 'Attribute/index', '1', '网站属性配置。', '', '0');
INSERT INTO `onethink_menu` VALUES ('64', '新增', '63', '0', 'Attribute/add', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('65', '编辑', '63', '0', 'Attribute/edit', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('66', '改变状态', '63', '0', 'Attribute/setStatus', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('67', '保存数据', '63', '0', 'Attribute/update', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('68', '系统', '0', '4', 'Config/group', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('69', '网站设置', '68', '1', 'Config/group', '0', '', '系统设置', '0');
INSERT INTO `onethink_menu` VALUES ('70', '配置管理', '68', '4', 'Config/index', '0', '', '系统设置', '0');
INSERT INTO `onethink_menu` VALUES ('71', '编辑', '70', '0', 'Config/edit', '0', '新增编辑和保存配置', '', '0');
INSERT INTO `onethink_menu` VALUES ('72', '删除', '70', '0', 'Config/del', '0', '删除配置', '', '0');
INSERT INTO `onethink_menu` VALUES ('73', '新增', '70', '0', 'Config/add', '0', '新增配置', '', '0');
INSERT INTO `onethink_menu` VALUES ('74', '保存', '70', '0', 'Config/save', '0', '保存配置', '', '0');
INSERT INTO `onethink_menu` VALUES ('75', '菜单管理', '68', '5', 'Menu/index', '0', '', '系统设置', '0');
INSERT INTO `onethink_menu` VALUES ('76', '导航管理', '68', '6', 'Channel/index', '0', '', '系统设置', '0');
INSERT INTO `onethink_menu` VALUES ('77', '新增', '76', '0', 'Channel/add', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('78', '编辑', '76', '0', 'Channel/edit', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('79', '删除', '76', '0', 'Channel/del', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('80', '分类管理', '68', '2', 'Category/index', '0', '', '系统设置', '0');
INSERT INTO `onethink_menu` VALUES ('81', '编辑', '80', '0', 'Category/edit', '0', '编辑和保存栏目分类', '', '0');
INSERT INTO `onethink_menu` VALUES ('82', '新增', '80', '0', 'Category/add', '0', '新增栏目分类', '', '0');
INSERT INTO `onethink_menu` VALUES ('83', '删除', '80', '0', 'Category/remove', '0', '删除栏目分类', '', '0');
INSERT INTO `onethink_menu` VALUES ('84', '移动', '80', '0', 'Category/operate/type/move', '0', '移动栏目分类', '', '0');
INSERT INTO `onethink_menu` VALUES ('85', '合并', '80', '0', 'Category/operate/type/merge', '0', '合并栏目分类', '', '0');
INSERT INTO `onethink_menu` VALUES ('86', '备份数据库', '68', '0', 'Database/index?type=export', '0', '', '数据备份', '0');
INSERT INTO `onethink_menu` VALUES ('87', '备份', '86', '0', 'Database/export', '0', '备份数据库', '', '0');
INSERT INTO `onethink_menu` VALUES ('88', '优化表', '86', '0', 'Database/optimize', '0', '优化数据表', '', '0');
INSERT INTO `onethink_menu` VALUES ('89', '修复表', '86', '0', 'Database/repair', '0', '修复数据表', '', '0');
INSERT INTO `onethink_menu` VALUES ('90', '还原数据库', '68', '0', 'Database/index?type=import', '0', '', '数据备份', '0');
INSERT INTO `onethink_menu` VALUES ('91', '恢复', '90', '0', 'Database/import', '0', '数据库恢复', '', '0');
INSERT INTO `onethink_menu` VALUES ('92', '删除', '90', '0', 'Database/del', '0', '删除备份文件', '', '0');
INSERT INTO `onethink_menu` VALUES ('93', '其他', '0', '5', 'other', '1', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('96', '新增', '75', '0', 'Menu/add', '0', '', '系统设置', '0');
INSERT INTO `onethink_menu` VALUES ('98', '编辑', '75', '0', 'Menu/edit', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('104', '下载管理', '102', '0', 'Think/lists?model=download', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('105', '配置管理', '102', '0', 'Think/lists?model=config', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('106', '行为日志', '16', '0', 'Action/actionlog', '0', '', '行为管理', '0');
INSERT INTO `onethink_menu` VALUES ('108', '修改密码', '16', '0', 'User/updatePassword', '1', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('109', '修改昵称', '16', '0', 'User/updateNickname', '1', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('110', '查看行为日志', '106', '0', 'action/edit', '1', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('112', '新增数据', '58', '0', 'think/add', '1', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('113', '编辑数据', '58', '0', 'think/edit', '1', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('114', '导入', '75', '0', 'Menu/import', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('115', '生成', '58', '0', 'Model/generate', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('116', '新增钩子', '57', '0', 'Addons/addHook', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('117', '编辑钩子', '57', '0', 'Addons/edithook', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('118', '文档排序', '3', '0', 'Article/sort', '1', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('119', '排序', '70', '0', 'Config/sort', '1', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('120', '排序', '75', '0', 'Menu/sort', '1', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('121', '排序', '76', '0', 'Channel/sort', '1', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('122', '用户管理', '0', '4', 'Ly/index', '1', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('123', '代理人信息', '122', '0', 'Ly/index', '0', '', '用户信息', '0');
INSERT INTO `onethink_menu` VALUES ('124', '消费者信息', '122', '0', 'Ly/uindex', '0', '', '用户信息', '0');
INSERT INTO `onethink_menu` VALUES ('125', '代理人权限', '122', '0', 'User/index', '0', '', '权限管理', '0');
INSERT INTO `onethink_menu` VALUES ('126', '消费者权限', '122', '0', 'User/index', '0', '', '权限管理', '0');
INSERT INTO `onethink_menu` VALUES ('127', '新增', '123', '0', 'Ly/add', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('128', '编辑', '123', '0', 'Ly/update', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('129', '新增', '124', '0', 'Ly/uadd', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('130', '编辑', '124', '0', 'Ly/uedit', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('169', '审核', '161', '0', 'PerCenter/bivdetail', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('153', '新增', '141', '0', 'AgCamp/cadd', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('133', '待审核', '131', '0', 'PerCenter/infor', '0', '', '营地管理', '0');
INSERT INTO `onethink_menu` VALUES ('136', '未读信息', '133', '0', 'PerCenter/infor', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('135', '编辑', '132', '0', 'PerCenter/pedit', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('137', '已审核', '131', '0', 'PerCenter/yishenhe', '0', '', '营地管理', '0');
INSERT INTO `onethink_menu` VALUES ('138', '代理中心', '0', '6', 'AgCamp/clist', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('141', '营地信息', '138', '0', 'AgCamp/clist', '0', '', '我的营地', '0');
INSERT INTO `onethink_menu` VALUES ('143', '编辑', '141', '0', 'AgCamp/cupdate', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('144', '删除', '141', '0', 'AgCamp/cdeletc', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('146', '活动设置', '138', '0', 'Game/glist', '0', '', '我的营地', '0');
INSERT INTO `onethink_menu` VALUES ('152', '营地消费情况', '138', '0', 'Sale/index', '0', '', '扩展', '0');
INSERT INTO `onethink_menu` VALUES ('147', '编辑', '146', '0', 'Game/gupdate', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('148', '游戏信息', '146', '0', 'Game/detail', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('149', '新增', '146', '0', 'Game/gadd', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('150', '编辑游戏信息', '146', '0', 'Game/edit', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('151', '新增', '146', '0', 'Game/add', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('154', '订单管理', '138', '0', 'Sale/order', '0', '', '扩展', '0');
INSERT INTO `onethink_menu` VALUES ('155', '查看详情', '154', '0', 'Sale/detail', '0', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('157', '完善信息', '16', '0', 'User/updateXinxi', '1', '', '', '0');
INSERT INTO `onethink_menu` VALUES ('162', '活动信息', '16', '0', 'PerCenter/camp', '0', '', '信息审核', '0');
INSERT INTO `onethink_menu` VALUES ('161', '营地信息', '16', '0', 'PerCenter/bivouac', '0', '', '信息审核', '0');
INSERT INTO `onethink_menu` VALUES ('163', '各营地营业情况', '16', '0', 'PerCenter/index', '0', '', '数据分析', '0');
INSERT INTO `onethink_menu` VALUES ('170', '审核', '162', '0', 'PerCenter/cdetail', '0', '', '', '0');

-- -----------------------------
-- Table structure for `onethink_model`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_model`;
CREATE TABLE `onethink_model` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '模型ID',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '模型标识',
  `title` char(30) NOT NULL DEFAULT '' COMMENT '模型名称',
  `extend` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '继承的模型',
  `relation` varchar(30) NOT NULL DEFAULT '' COMMENT '继承与被继承模型的关联字段',
  `need_pk` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '新建表时是否需要主键字段',
  `field_sort` text NOT NULL COMMENT '表单字段排序',
  `field_group` varchar(255) NOT NULL DEFAULT '1:基础' COMMENT '字段分组',
  `attribute_list` text NOT NULL COMMENT '属性列表（表的字段）',
  `template_list` varchar(100) NOT NULL DEFAULT '' COMMENT '列表模板',
  `template_add` varchar(100) NOT NULL DEFAULT '' COMMENT '新增模板',
  `template_edit` varchar(100) NOT NULL DEFAULT '' COMMENT '编辑模板',
  `list_grid` text NOT NULL COMMENT '列表定义',
  `list_row` smallint(2) unsigned NOT NULL DEFAULT '10' COMMENT '列表数据长度',
  `search_key` varchar(50) NOT NULL DEFAULT '' COMMENT '默认搜索字段',
  `search_list` varchar(255) NOT NULL DEFAULT '' COMMENT '高级搜索的字段',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  `engine_type` varchar(25) NOT NULL DEFAULT 'MyISAM' COMMENT '数据库引擎',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COMMENT='文档模型表';

-- -----------------------------
-- Records of `onethink_model`
-- -----------------------------
INSERT INTO `onethink_model` VALUES ('1', 'document', '基础文档', '0', '', '1', '{\"1\":[\"1\",\"2\",\"3\",\"4\",\"5\",\"6\",\"7\",\"8\",\"9\",\"10\",\"11\",\"12\",\"13\",\"14\",\"15\",\"16\",\"17\",\"18\",\"19\",\"20\",\"21\",\"22\"]}', '1:基础', '', '', '', '', 'id:编号\r\ntitle:标题:article/index?cate_id=[category_id]&pid=[id]\r\ntype|get_document_type:类型\r\nlevel:优先级\r\nupdate_time|time_format:最后更新\r\nstatus_text:状态\r\nview:浏览\r\nid:操作:[EDIT]&cate_id=[category_id]|编辑,article/setstatus?status=-1&ids=[id]|删除', '0', '', '', '1383891233', '1384507827', '1', 'MyISAM');
INSERT INTO `onethink_model` VALUES ('2', 'article', '文章', '1', '', '1', '{\"1\":[\"3\",\"24\",\"11\",\"10\",\"25\",\"5\",\"2\",\"12\"],\"2\":[\"16\",\"17\",\"26\",\"20\",\"14\",\"9\",\"13\",\"19\"]}', '1:基础,2:扩展', '', '', '', '', 'id:编号\r\ntitle:标题:article/edit?cate_id=[category_id]&id=[id]\r\ncontent:内容', '0', '', '', '1383891243', '1453171617', '1', 'MyISAM');
INSERT INTO `onethink_model` VALUES ('3', 'download', '下载', '1', '', '1', '{\"1\":[\"3\",\"28\",\"30\",\"32\",\"2\",\"5\",\"31\"],\"2\":[\"13\",\"10\",\"27\",\"9\",\"12\",\"16\",\"17\",\"19\",\"11\",\"20\",\"14\",\"29\"]}', '1:基础,2:扩展', '', '', '', '', 'id:编号\r\ntitle:标题', '0', '', '', '1383891252', '1387260449', '1', 'MyISAM');
INSERT INTO `onethink_model` VALUES ('4', 'agcamp', '露营信息文档', '0', '', '1', '{\"1\":[\"47\",\"45\",\"44\",\"46\",\"34\",\"37\",\"38\",\"36\",\"39\"],\"2\":[\"41\",\"42\",\"43\"]}', '1:营地信息,2:游戏设置', '', 'clist', '', '', 'id:营地编号\r\nbivName:营地名称\r\nbivAdd:地址\r\ncount:订单数量\r\nbivVisit:访问数量\r\nbivEva:总评\r\nid:操作:[EDIT]&cate_id=[category_id]|编辑,article/setstatus?status=-1&ids=[id]|删除', '10', '', '', '1453171712', '1453191462', '1', 'MyISAM');
INSERT INTO `onethink_model` VALUES ('5', 'lagent', '代理人信息', '0', '', '1', '', '1:基础', '', '', '', '', '', '10', '', '', '1457510521', '1457510521', '1', 'MyISAM');

-- -----------------------------
-- Table structure for `onethink_picture`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_picture`;
CREATE TABLE `onethink_picture` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键id自增',
  `path` varchar(255) NOT NULL DEFAULT '' COMMENT '路径',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '图片链接',
  `md5` char(32) NOT NULL DEFAULT '' COMMENT '文件md5',
  `sha1` char(40) NOT NULL DEFAULT '' COMMENT '文件 sha1编码',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `onethink_picture`
-- -----------------------------
INSERT INTO `onethink_picture` VALUES ('1', '/Uploads/Picture/2016-01-17/569b4453f05d0.jpg', '', 'ffcd00b5076b75117a2f721d2e0991db', '79046a1cc4ef948aa686cacb4ff1a5303da86720', '1', '1453016147');
INSERT INTO `onethink_picture` VALUES ('2', '/Uploads/Picture/2016-01-17/569b446e78672.jpg', '', 'dab2145ae36e499d45a82313722cd5ea', 'd1f448d1f97ad93ac9489199b139b1b3641f4db5', '1', '1453016174');
INSERT INTO `onethink_picture` VALUES ('3', '/Uploads/Picture/2016-01-19/569de1a41e7ea.jpg', '', '2c28e014b66879ad967e3605266236f3', '5279d40e3d9ed427ad846447c68cb96fa7c4df46', '1', '1453187491');

-- -----------------------------
-- Table structure for `onethink_ucenter_admin`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_ucenter_admin`;
CREATE TABLE `onethink_ucenter_admin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '管理员ID',
  `member_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '管理员用户ID',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '管理员状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='管理员表';


-- -----------------------------
-- Table structure for `onethink_ucenter_app`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_ucenter_app`;
CREATE TABLE `onethink_ucenter_app` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '应用ID',
  `title` varchar(30) NOT NULL COMMENT '应用名称',
  `url` varchar(100) NOT NULL COMMENT '应用URL',
  `ip` char(15) NOT NULL COMMENT '应用IP',
  `auth_key` varchar(100) NOT NULL COMMENT '加密KEY',
  `sys_login` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '同步登陆',
  `allow_ip` varchar(255) NOT NULL COMMENT '允许访问的IP',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '应用状态',
  PRIMARY KEY (`id`),
  KEY `status` (`status`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='应用表';


-- -----------------------------
-- Table structure for `onethink_ucenter_member`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_ucenter_member`;
CREATE TABLE `onethink_ucenter_member` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `username` char(16) NOT NULL COMMENT '用户名',
  `password` char(32) NOT NULL COMMENT '密码',
  `email` char(32) NOT NULL COMMENT '用户邮箱',
  `mobile` char(15) NOT NULL COMMENT '用户手机',
  `reg_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '注册时间',
  `reg_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '注册IP',
  `last_login_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后登录时间',
  `last_login_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '最后登录IP',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) DEFAULT '0' COMMENT '用户状态',
  `userSex` varchar(255) DEFAULT NULL COMMENT '性别',
  `userFace` varchar(255) DEFAULT NULL COMMENT '用户头像',
  `userPower` int(255) DEFAULT NULL COMMENT '体力值',
  `userBrains` int(255) DEFAULT NULL COMMENT '智力值',
  `userExp` int(255) DEFAULT NULL COMMENT '经验值',
  `userGrade` int(255) DEFAULT NULL COMMENT '等级值',
  `userGold` int(255) DEFAULT NULL COMMENT '金币',
  `userBlood` int(255) DEFAULT NULL COMMENT '血量',
  `userAdd` int(255) DEFAULT NULL COMMENT '用户所在地',
  `identity` int(255) NOT NULL COMMENT '身份证号',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COMMENT='用户表';

-- -----------------------------
-- Records of `onethink_ucenter_member`
-- -----------------------------
INSERT INTO `onethink_ucenter_member` VALUES ('1', 'admin', 'b8bff27383857f47ee62161cb320aee6', '908214521@qq.com', '111111', '1447931494', '2130706433', '1459774930', '2130706433', '1447931494', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1');
INSERT INTO `onethink_ucenter_member` VALUES ('2', 'admin1', '276f9c620876c9d24331c9309e2f2ad1', '123@qq.com', '111111', '1449663531', '2130706433', '1450091888', '2130706433', '1449663531', '1', '', '', '', '', '', '1', '', '', '', '0');
INSERT INTO `onethink_ucenter_member` VALUES ('3', 'guest', '4bef9052ba37e2da8cd3037883319ec8', '1@qq.com', '111111', '1449750769', '2130706433', '1450091888', '2130706433', '1449750769', '1', '', '', '', '', '', '1', '', '', '', '0');
INSERT INTO `onethink_ucenter_member` VALUES ('4', 'guest1', '276f9c620876c9d24331c9309e2f2ad1', '999@qq.com', '111111', '1450094032', '2130706433', '1457520312', '2130706433', '1450094032', '1', '', '', '', '', '', '1', '', '', '', '0');
INSERT INTO `onethink_ucenter_member` VALUES ('5', 'guest2', '276f9c620876c9d24331c9309e2f2ad1', 'abc@qq.com', '111111', '1457093699', '2130706433', '1457094008', '2130706433', '1457093699', '1', '', '', '', '', '', '1', '', '', '', '0');
INSERT INTO `onethink_ucenter_member` VALUES ('6', 'guest3', '276f9c620876c9d24331c9309e2f2ad1', '12@qq.com', '111111', '1457093778', '2130706433', '1457093821', '2130706433', '1457093778', '1', '', '', '', '', '', '1', '', '', '', '0');
INSERT INTO `onethink_ucenter_member` VALUES ('7', 'agent1', '93b004e07a6bfd69ae6da6a74b9ed2ee', '90821@qq.com', '', '1457607121', '2130706433', '1457607263', '2130706433', '1457607121', '1', '', '', '', '', '', '1', '', '', '', '0');
INSERT INTO `onethink_ucenter_member` VALUES ('9', 'agent2', 'b94206ebf71d934ab311997d0379e8b9', '888@qq.com', '', '1457695906', '2130706433', '1457695932', '2130706433', '1457695906', '1', '', '', '', '', '', '', '', '', '', '0');

-- -----------------------------
-- Table structure for `onethink_ucenter_member_copy`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_ucenter_member_copy`;
CREATE TABLE `onethink_ucenter_member_copy` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `username` char(16) NOT NULL COMMENT '用户名',
  `password` char(32) NOT NULL COMMENT '密码',
  `email` char(32) NOT NULL COMMENT '用户邮箱',
  `mobile` char(15) NOT NULL COMMENT '用户手机',
  `reg_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '注册时间',
  `reg_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '注册IP',
  `last_login_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后登录时间',
  `last_login_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '最后登录IP',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) DEFAULT '0' COMMENT '用户状态',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='用户表';

-- -----------------------------
-- Records of `onethink_ucenter_member_copy`
-- -----------------------------
INSERT INTO `onethink_ucenter_member_copy` VALUES ('1', 'admin', 'b8bff27383857f47ee62161cb320aee6', '908214521@qq.com', '111111', '1447931494', '2130706433', '1457087184', '2130706433', '1447931494', '1');
INSERT INTO `onethink_ucenter_member_copy` VALUES ('2', 'admin1', '276f9c620876c9d24331c9309e2f2ad1', '123@qq.com', '111111', '1449663531', '2130706433', '0', '0', '1449663531', '1');
INSERT INTO `onethink_ucenter_member_copy` VALUES ('3', 'guest', '4bef9052ba37e2da8cd3037883319ec8', '1@qq.com', '111111', '1449750769', '2130706433', '1450091888', '2130706433', '1449750769', '1');
INSERT INTO `onethink_ucenter_member_copy` VALUES ('4', 'guest1', '276f9c620876c9d24331c9309e2f2ad1', '999@qq.com', '', '1450094032', '2130706433', '1456298097', '2130706433', '1450094032', '1');

-- -----------------------------
-- Table structure for `onethink_ucenter_setting`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_ucenter_setting`;
CREATE TABLE `onethink_ucenter_setting` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '设置ID',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置类型（1-用户配置）',
  `value` text NOT NULL COMMENT '配置数据',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='设置表';


-- -----------------------------
-- Table structure for `onethink_url`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_url`;
CREATE TABLE `onethink_url` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '链接唯一标识',
  `url` char(255) NOT NULL DEFAULT '' COMMENT '链接地址',
  `short` char(100) NOT NULL DEFAULT '' COMMENT '短网址',
  `status` tinyint(2) NOT NULL DEFAULT '2' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_url` (`url`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='链接表';


-- -----------------------------
-- Table structure for `onethink_userdata`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_userdata`;
CREATE TABLE `onethink_userdata` (
  `uid` int(10) unsigned NOT NULL COMMENT '用户id',
  `type` tinyint(3) unsigned NOT NULL COMMENT '类型标识',
  `target_id` int(10) unsigned NOT NULL COMMENT '目标id',
  UNIQUE KEY `uid` (`uid`,`type`,`target_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

