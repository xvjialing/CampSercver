<?php
namespace Admin\Controller;


class AgCampController extends AdminController{
	public function clist(){
		$bivName       =   I('bivName');
		$map['status']  =   array('egt',0);
		    
		if(is_numeric($bivName)){     // 检测变量是否为数字或数字字符串 ,是则返回ture,否则返回false
			$map['bivouac|bivName']=   array(intval($bivName),array('like','%'.$bivName.'%'),'_multi'=>true);
		}else{
			$map['bivName']    =   array('like', '%'.(string)$bivName.'%');
		}
		
		$list   = $this->lists('Lbivouac', $map);
		int_to_string($list,array('Status'=>array(1=>'是',0=>'否')));              //数字转为字符串
		$clist=D('clist');
		$sql='SELECT count(*) FROM  onethink_ucenter_member,onethink_lagent,onethink_lbivouac,onethink_loder WHERE onethink_ucenter_member.id='.UID.' AND '.UID.'=onethink_lagent.agentID  AND onethink_lagent.agentID=onethink_lbivouac.agentID AND onethink_lbivouac.bivouacID=onethink_loder.bivouacID';
		
		$voList = $clist->query($sql);	
		foreach($voList as $key=>$val){
			$this->assign('count',$val['count(*)']);
		} 
		
		$this->assign('_list', $list);
		
		// 记录当前列表页的cookie
		Cookie('__forward__',$_SERVER['REQUEST_URI']);		
		$this->meta_title = '营地信息';
		$this->display(); 
    }
    public function toogleSta($bivouacID,$value = 1){
    	$this->editRow('Lbivouac', array('Status'=>$value), array('bivouacID'=>$bivouacID));
    }
	public function camp(){
		$this->display();
	}
	public function cadd(){
		$this->display();
	}
	public function cdelete(){
		$this->display();
	}
	public function cupadte(){
		$this->display();
	}
}