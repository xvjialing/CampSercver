<?php
namespace Admin\Controller;
use Think\Controller;
use User\Api\UserApi;

class PerCenterController extends AdminController {
	public function person(){
		$member = M('UcenterMember');
		$user = $member->find(UID);
		$this->assign('user',$user);
		$this->display();
		
		Cookie('__forward__',$_SERVER['REQUEST_URI']);
	}
	
	public function pedit(){
		if(IS_POST){
			$Member = M('UcenterMember');
/* 			$Api    =   new UserApi();
			$res    =   $Api->updateInfo(UID, $password, $data);
			if($res['status']){
				$this->success('修改密码成功！');
			}else{
				$this->error($res['info']);
			} */
			
			$data = $Member->create();
			if($data){
				if($Member->save()!== false){
					// S('DB_CONFIG_DATA',null);
					//记录行为
					action_log('update_menu', 'UcenterMember', $data['id'], UID);
					$this->success('更新成功', Cookie('__forward__'));
				} else {
					$this->error('更新失败');
				}
			} else {
				$this->error($Member->getError());
			}
		} else {
			/* 获取数据 */
			$member = M('UcenterMember');
		    $user = $member->find(UID);
			if(false === $user){
				$this->error('获取后台菜单信息错误');
			}
			$this->assign('user', $user);
			$this->meta_title = '修改个人信息';
			$this->display();
		}
	}
	

	public function infor(){
		$this->display();
	}
}